"""
"The half of the FFT your analyser throws away": phase, real and imaginary.

One timeline (timeline_fft.json, from captions_fft.py) drives everything. Each
frame is rebuilt from the clock: 3D world (own projection, so we control the
camera exactly), 2D overlay (title, maths row, captions, panels, mascot).

World axes: x = time (going back), y = real part, z = imaginary part.
Looking down the time axis (END view) you see the complex plane:
real across, imaginary up.

Render a slice:  T0=0 T1=40 manim -qh fft_story.py FFTStory -o part.mp4
Quick preview:   PREVIEW=1 manim -ql fft_story.py FFTStory
"""
import json
import os
import textwrap
import numpy as np
from manim import *                                       # noqa: F401,F403
from manim.utils.family import extract_mobject_family_members

config.pixel_width, config.pixel_height = 1920, 1080
config.frame_rate = 60
if os.environ.get("PREVIEW"):
    config.pixel_width, config.pixel_height, config.frame_rate = 960, 540, 15
config.background_color = "#111110"

SURF, INKc, INK2c, MUTEDc = "#111110", "#f0efec", "#c3c2b7", "#898781"
GRIDc, AXc = "#2a2a28", "#5a5955"
BLUEc, ORANGEc, GOODc, BADc = "#3987e5", "#d95926", "#2bb24c", "#e0503a"
SANS = "DejaVu Sans"
TAU2 = 2 * np.pi

TL = json.load(open(os.environ.get("TIMELINE", "timeline_fft.json")))
DUR = TL["duration"]
SC = {s["key"]: s for s in TL["scenes"]}
C = {k: s["cues"] for k, s in SC.items()}
LINES = [l for s in TL["scenes"] for l in s["lines"]]
ORDER = [s["key"] for s in TL["scenes"]]
T0 = float(os.environ.get("T0", 0))
T1 = float(os.environ.get("T1", DUR))
FW, FH = config.frame_width, config.frame_height


def ease(x):
    x = float(np.clip(x, 0, 1))
    return x * x * (3 - 2 * x)


def ramp(t, t0, d=0.6):
    return ease((t - t0) / d)


def win(t, a, b, fade=0.5):
    """1 inside [a, b], soft edges."""
    return min(ramp(t, a - fade / 2, fade), 1 - ramp(t, b - fade / 2, fade))


def FIG(fx, fy):
    return np.array([(fx - 0.5) * FW, (fy - 0.5) * FH, 0])


_tc, _xc = {}, {}


def T(s, size=28, color=INKc, weight=NORMAL):
    k = (s, size, color, weight)
    if k not in _tc:
        _tc[k] = Text(s, font=SANS, font_size=size, color=color, weight=weight)
    return _tc[k].copy()


def TEX(s, size=40):
    k = (s, size)
    if k not in _xc:
        _xc[k] = MathTex(s, font_size=size, color=INKc)
    return _xc[k].copy()


def poly(points, color, width, opacity=1.0):
    m = VMobject(stroke_color=color, stroke_width=width, stroke_opacity=opacity)
    m.set_points_as_corners(np.asarray(points))
    return m


def glow(points, color, width=3.0, opacity=1.0):
    return VGroup(poly(points, color, width * 3.4, 0.12 * opacity), poly(points, color, width, opacity))


# ------------------------------------------------------------------ signals
def machine(t):
    """The messy machine signal from the harmonics video (t in turns)."""
    ph = t % 1.0
    tau = (ph - 0.32) % 1.0
    ring = np.exp(-tau / 0.15) * np.sin(TAU2 * 6.0 * tau)
    return (0.55 * np.sin(TAU2 * t) + 0.3 * np.sin(2 * TAU2 * t + 0.9) + 1.4 * ring) / 1.16


ODD = np.arange(1, 16, 2)
AMP = 4 / (np.pi * ODD)
RNG = np.random.default_rng(7)
PH_SQUARE = np.zeros(len(ODD))
PH_SPIKE = np.full(len(ODD), np.pi / 2)
PH_NOISE = RNG.uniform(0, TAU2, len(ODD))


def odd_sum(tt, ph):
    return sum(a * np.sin(TAU2 * n * tt + p) for a, n, p in zip(AMP, ODD, ph))


# winding: 4 turns of the machine signal, wrapped at speed fw (in multiples of running speed)
N_W = 1400
S_W = np.linspace(0, 4, N_W, endpoint=False)
F_W = machine(S_W)
FW_GRID = np.linspace(0.3, 4.45, 1700)
SPEC_TRACE = np.array([2 * abs(np.mean(F_W * np.exp(-1j * TAU2 * f * S_W))) for f in FW_GRID])


def com(fw):
    return np.mean(F_W * np.exp(-1j * TAU2 * fw * S_W))


def dial(t):
    """winding speed over the 'wind' scene: slow up to 1X, then sweep to 4.4X; held at 2X for 'parts'."""
    c = C["wind"]
    a, hit, end = c["dial"] + 0.4, c["hit"] + 1.0, SC["wind"]["end"] - 1.2
    if t < c["wrap"] + 0.3:
        return 0.0
    if t < c["dial"] + 0.4:                        # first wrap: 0 -> 0.6X
        return 0.6 * ramp(t, c["wrap"] + 0.3, 3.0)
    if t < hit:
        return 0.6 + 0.4 * (t - a) / (hit - a)
    if t < end:
        return 1.0 + 3.4 * (t - hit) / (end - hit)
    if t < SC["parts"]["start"]:                   # glide back to 2X
        return 4.4 - 2.4 * ramp(t, end, SC["parts"]["start"] - end)
    return 2.0


# ------------------------------------------------------------------ camera
XL = 6.5          # time axis length (world)
W = 1.45          # wall / floor distance
# (theta, phi, zoom, screen offset x, offset y)
END_V = (0.0, 90.0, 1.55, -0.9, 0.35)
PERSP = (-60.0, 66.0, 0.92, 0.6, 0.1)
END_Z = (0.0, 90.0, 8.0, -0.9, 0.0)         # zoomed in on the dot for real/imaginary
TWIN_V = (0.0, 90.0, 2.6, -1.4, 0.15)        # close-up of the plane for the twin-arrow build
CAMKEYS = [(0, END_V)]
a, tw, w_ = C["arrow"], SC["two"], C["two"]
CAMKEYS += [(a["helix"] + 0.3, END_V), (a["helix"] + 2.8, PERSP),
            (tw["start"] - 0.3, PERSP), (tw["start"] + 1.4, TWIN_V),           # look straight at the complex plane
            (w_["time"] + 0.2, TWIN_V), (w_["time"] + 2.6, PERSP),             # let time run: corkscrews
            (w_["mirror"] - 0.2, PERSP), (w_["mirror"] + 1.8, END_V),
            (SC["wind"]["start"] - 0.2, END_V), (SC["wind"]["start"] + 0.6, PERSP),
            (C["wind"]["dot"] - 0.4, PERSP), (C["wind"]["dot"] + 1.6, END_V),
            (C["parts"]["freeze"] + 0.3, END_V), (C["parts"]["freeze"] + 2.0, END_Z), (DUR + 1, END_Z)]
CAMKEYS.sort(key=lambda k: k[0])


def camera(t):
    for (t0, a0), (t1, a1) in zip(CAMKEYS, CAMKEYS[1:]):
        if t0 <= t <= t1:
            u = ramp(t, t0, max(t1 - t0, 1e-3))
            return tuple(x + (y - x) * u for x, y in zip(a0, a1))
    return CAMKEYS[-1][1]


# ------------------------------------------------------------------ the twin arrows' angle (scene "two")
# spin, glide to a stop pointing along +real at 'ontop', hold, quarter turn at 'opp', hold, then spin again
_c2, _s2 = C["two"], SC["two"]
OM2 = TAU2 * 0.32
_stop = _c2["ontop"] + 0.2
_k = max(1, round(OM2 * (_stop - _s2["start"]) / TAU2))
OM_A = TAU2 * _k / (_stop - _s2["start"])          # so the spin lands exactly on a whole turn at _stop
TH_STOP = TAU2 * _k
OPP0, OPP_D = _c2["opp"] + 0.3, 1.4                # quarter turn
SLIDE0, SLIDE_A = _c2["slide"] + 0.4, 1.2          # spin up again


def theta2(t):
    s = _s2["start"]
    if t < _stop - 1.6:
        return OM_A * (t - s)
    if t < _stop:                                   # blend the spin into a hold on a whole turn
        w = ramp(t, _stop - 1.6, 1.6)
        return OM_A * (t - s) + w * (TH_STOP - OM_A * (t - s))
    th = TH_STOP + (np.pi / 2) * ramp(t, OPP0, OPP_D)
    if t > SLIDE0:
        tau = t - SLIDE0
        th += OM2 * (tau ** 2 / (2 * SLIDE_A) if tau < SLIDE_A else tau - SLIDE_A / 2)
    return th


# ------------------------------------------------------------------ maths row
EQS = sorted([
    (SC["arrow"]["lines"][4]["start"], r"e^{i\omega t}=\cos\omega t+i\,\sin\omega t"),
    (C["two"]["twin"] + 0.3, r"\tfrac12\,e^{\,i\omega t}\quad\text{and}\quad\tfrac12\,e^{-i\omega t}"),
    (C["two"]["tip"] + 0.3, r"\tfrac12\,e^{\,i\omega t}+\tfrac12\,e^{-i\omega t}"),
    (C["two"]["slide"] + 0.3, r"\tfrac12\,e^{\,i\omega t}+\tfrac12\,e^{-i\omega t}=\cos\omega t"),
    (C["two"]["conj"] + 0.3, r"X(-f)=\overline{X(f)}"),
    (C["two"]["fold"] + 0.3, r"\text{one-sided amplitude}=2\,|X(f)|"),
    (C["wind"]["wrap"] + 0.3, r"X(f)=\frac{1}{T}\int_0^{T} x(t)\,e^{-i2\pi f t}\,dt"),
    (C["parts"]["coords"] + 0.2, r"X_n=\tfrac12\,(a_n-i\,b_n)"),
    (C["parts"]["polar"] + 0.2, r"2\,|X_n|=\sqrt{a_n^2+b_n^2}=c_n"),
    (C["parts"]["angle"] + 0.2, r"x(t)=\sum_n c_n\cos(n\omega_0 t+\theta_n),\qquad \theta_n=\arg X_n"),
    (C["shape"]["spin"] + 0.2, r"|X_n|\ \text{fixed},\qquad \arg X_n\ \text{changing}"),
    (C["life"]["balance"] + 0.2, r"\text{phase}=\arg X_1"),
], key=lambda e: e[0])
EQ_END = DUR - 2.2


# ------------------------------------------------------------------ mascot schedule
EVENTS = [("appear", 1.0, 0.6), ("surprise", C["hook"]["collapse"] + 0.8, 2.6),
          ("excited", C["arrow"]["helix"] + 1.5, 2.4), ("dizzy", C["wind"]["wrap"] + 0.6, 3.2),
          ("excited", C["wind"]["hit"] + 0.6, 2.6), ("happy", C["parts"]["polar"] + 0.3, 2.4),
          ("surprise", C["shape"]["spin"] + 1.0, 2.6), ("happy", C["life"]["close"] + 0.2, 3.0)]
BUBBLES = [(C["hook"]["collapse"] + 0.9, 2.4, "Same spectrum?!"),
           (C["arrow"]["helix"] + 1.6, 2.2, "A corkscrew!"),
           (C["two"]["opp"] + 1.8, 2.2, "Gone!"),
           (C["wind"]["wrap"] + 0.8, 2.2, "Wheee…"),
           (C["wind"]["hit"] + 0.7, 2.2, "Found one!"),
           (C["shape"]["spin"] + 1.1, 2.4, "Same bars, new me."),
           (C["life"]["close"] + 0.4, 2.6, "Keep the phase!")]


def level(kind, t):
    v = 0.0
    for k, t0, d in EVENTS:
        if k == kind:
            v = max(v, win(t, t0, t0 + d, 0.4))
    return v


# ------------------------------------------------------------------ scene
class FFTStory(Scene):
    def construct(self):
        self.clock = ValueTracker(T0)
        self.layer = VGroup()
        self.add(self.layer)
        self.layer.add_updater(lambda m, dt: None)
        tick = Mobject()
        tick.add_updater(lambda m: self.frame(self.clock.get_value()))
        self.add(tick)
        self.frame(T0)
        self.play(self.clock.animate.set_value(T1), run_time=T1 - T0, rate_func=linear)

    # -------------------------------------------------------------- projection
    def set_view(self, t):
        th, ph, self.zoom, ox, oy = camera(t)
        th, ph = np.radians(th), np.radians(ph)
        d = np.array([np.cos(th) * np.sin(ph), np.sin(th) * np.sin(ph), np.cos(ph)])
        fwd = -d
        right = np.cross(fwd, [0, 0, 1.0])
        right /= np.linalg.norm(right)
        up = np.cross(right, fwd)
        self.basis = np.stack([right, up, d])
        self.off = np.array([ox, oy, 0.0])

    def proj(self, pts):
        pts = np.atleast_2d(pts).astype(float).copy()
        pts[:, 0] -= XL / 2                     # rotate about the middle of the time axis
        q = pts @ self.basis.T
        f = 18.0
        k = f / (f - q[:, 2])
        out = np.zeros_like(q)
        out[:, 0] = q[:, 0] * k * self.zoom
        out[:, 1] = q[:, 1] * k * self.zoom
        return out + self.off

    def P(self, x, y, z):
        return self.proj(np.array([[x, y, z]]))[0]

    def W3(self, x, y, z):
        x = np.broadcast_to(np.asarray(x, float), np.broadcast_shapes(np.shape(x), np.shape(y), np.shape(z)))
        return np.stack([x, np.broadcast_to(y, x.shape), np.broadcast_to(z, x.shape)], 1)

    # -------------------------------------------------------------- per frame
    def frame(self, t):
        self.set_view(t)
        g = VGroup()
        cur = ORDER[0]
        for k in ORDER:
            if t >= SC[k]["start"] - 0.05:
                cur = k
        three_d = win(t, SC["arrow"]["start"] - 0.4, SC["parts"]["end"] - 0.6, 0.9)
        if three_d > 0.01:
            self.world(t, g, three_d)
        if t < SC["arrow"]["start"] + 0.5:
            self.hook(t, g)
        self.two_panel(t, g)
        self.wind_panel(t, g)
        if SC["shape"]["start"] - 0.6 <= t <= SC["shape"]["end"]:
            self.shape(t, g)
        if SC["life"]["start"] - 0.6 <= t:
            self.life(t, g)
        self.hud(t, g, cur)
        self.layer.submobjects = [g]
        self.moving_mobjects = extract_mobject_family_members([self.layer])

    # -------------------------------------------------------------- 3D world
    def world(self, t, g, A):
        ca, c2, cw = C["arrow"], C["two"], C["wind"]
        # axes: time, real, imaginary
        g.add(poly(self.proj(self.W3([0, XL + 0.2], 0, 0)), AXc, 2.2, A))
        for y0, y1, z0, z1 in ((-1.3, 1.3, 0, 0), (0, 0, -1.3, 1.3)):
            g.add(poly(self.proj(np.array([[0, y0, z0], [0, y1, z1]])), AXc, 2.2, A))
        self.axis_labels(g, A, t)
        t_arrow = SC["arrow"]["start"] - 0.4 <= t < SC["two"]["end"]
        rate = 0.45                                         # turns per second of the arrow
        spin = TAU2 * rate * t
        span = 3.0                                          # turns shown along the time axis
        xs = np.linspace(0, XL, 360)
        back = xs / XL * span                               # turns into the past
        if t_arrow:
            # walls with a faint grid (floor z = -W, back wall y = +W)
            wa = A * win(t, SC["arrow"]["start"], SC["two"]["end"] - 0.6, 0.8) * (1 - 0.8 * self.endness())
            if wa > 0.02:
                for xx in np.linspace(0, XL, 7):
                    g.add(poly(self.proj(np.array([[xx, -W, -W], [xx, W, -W], [xx, W, W]])), GRIDc, 1.5, wa))
                for yy in np.linspace(-W, W, 5):
                    g.add(poly(self.proj(np.array([[0, yy, -W], [XL, yy, -W]])), GRIDc, 1.5, wa))
                for zz in np.linspace(-W, W, 5):
                    g.add(poly(self.proj(np.array([[0, W, zz], [XL, W, zz]])), GRIDc, 1.5, wa))
        # ---- scene "arrow": one rotating arrow, its corkscrew and two shadows
        if SC["arrow"]["start"] - 0.4 <= t < SC["two"]["start"] + 0.6:
            fa = A * (1 - ramp(t, SC["two"]["start"] - 0.2, 0.8))
            r = 1.0
            circ = np.linspace(0, TAU2, 120)
            g.add(poly(self.proj(self.W3(0, r * np.cos(circ), r * np.sin(circ))), MUTEDc, 1.6, 0.6 * fa))
            tip = self.P(0, r * np.cos(spin), r * np.sin(spin))
            g.add(Line(self.P(0, 0, 0), tip, stroke_color=BLUEc, stroke_width=5, stroke_opacity=fa))
            g.add(Dot(tip, radius=0.07, color=BLUEc).set_opacity(fa))
            grow = ramp(t, ca["helix"] + 0.5, 2.6)
            if grow > 0.01:
                n = max(2, int(len(xs) * grow))
                ang = spin - TAU2 * back[:n]
                g.add(glow(self.proj(self.W3(xs[:n], r * np.cos(ang), r * np.sin(ang))), BLUEc, 3.0, fa))
                re_a = ramp(t, ca["real"] + 0.2, 1.0) * fa
                if re_a > 0.01:      # floor shadow: real part (cosine)
                    g.add(glow(self.proj(self.W3(xs[:n], r * np.cos(ang), -W)), BLUEc, 2.4, 0.75 * re_a))
                    self.label(g, (XL, -1.1, -W), "real · cos ωt", BLUEc, re_a)
                im_a = ramp(t, ca["imag"] + 0.2, 1.0) * fa
                if im_a > 0.01:      # back-wall shadow: imaginary part (sine)
                    g.add(glow(self.proj(self.W3(xs[:n], W, r * np.sin(ang))), GOODc, 2.4, 0.75 * im_a))
                    self.label(g, (XL, W, 1.15), "imaginary · sin ωt", GOODc, im_a)
        # ---- scene "two": two counter-rotating arrows and their sum
        if SC["two"]["start"] - 0.3 <= t < SC["two"]["end"]:
            self.twins(t, g, A, xs, back)
        # ---- scenes "wind" and "parts": the machine signal wrapped round the time axis
        if SC["wind"]["start"] - 0.3 <= t:
            fa = A * ramp(t, SC["wind"]["start"], 0.8)
            fw = dial(t)
            z = F_W * np.exp(-1j * TAU2 * fw * S_W)
            xw = S_W / 4 * XL
            fade_sig = 1 - 0.93 * ramp(t, C["parts"]["freeze"] + 0.2, 1.4)
            g.add(glow(self.proj(self.W3(xw, z.real, z.imag)), INKc, 2.0, 0.85 * fa * fade_sig))
            da = ramp(t, cw["dot"] + 0.2, 0.6) * fa
            if da > 0.01:
                X = com(fw)
                v = 2 * X                                       # one-sided: the length you read on the analyser
                mid = XL / 2
                tipw = (mid, v.real, v.imag)
                hl = 1.0 + 0.6 * float(np.clip((abs(v) - 0.12) / 0.2, 0, 1))
                g.add(Line(self.P(mid, 0, 0), self.P(*tipw), stroke_color=ORANGEc, stroke_width=6 * hl,
                           stroke_opacity=da))
                g.add(Dot(self.P(*tipw), radius=0.09 * hl, color=ORANGEc).set_opacity(da))
                self.parts_overlay(t, g, v, mid, da)

    def twins(self, t, g, A, xs, back):
        """scene 'two', built step by step in the complex plane (x = 0), then let time run."""
        c, s = C["two"], SC["two"]
        fa = A * ramp(t, s["start"], 0.8) * (1 - ramp(t, s["end"] - 1.0, 0.8))
        r = 0.62
        th = theta2(t)
        e1 = np.array([0, np.cos(th), np.sin(th)]) * r          # 1/2 e^{+iwt}  (blue, anticlockwise)
        e2 = np.array([0, np.cos(th), -np.sin(th)]) * r         # 1/2 e^{-iwt}  (orange, clockwise)
        O = np.zeros(3)
        circ = np.linspace(0, TAU2, 120)
        g.add(poly(self.proj(self.W3(0, r * np.cos(circ), r * np.sin(circ))), MUTEDc, 1.5, 0.45 * fa))
        # 1) a real vibration lives on one line: highlight the real axis
        la = fa * win(t, c["pair"] + 0.3, c["twin"], 0.8)
        if la > 0.01:
            g.add(Line(self.P(0, -1.35, 0), self.P(0, 1.35, 0), stroke_color=INKc, stroke_width=9,
                       stroke_opacity=0.35 * la))
        # one arrow: its tip goes up and down too (green: its imaginary part)
        ia = fa * win(t, c["pair"] + 1.5, c["mirrorpair"], 0.8)
        if ia > 0.01:
            g.add(DashedLine(self.P(0, e1[1], 0), self.P(*e1), dash_length=0.07, stroke_color=GOODc, stroke_width=5,
                             stroke_opacity=ia))
        corks = ramp(t, c["time"] + 0.6, 1.6) * fa                 # corkscrews only once time runs
        tw_a = fa * ramp(t, c["twin"] + 0.2, 0.8)                   # the twin appears
        tip = ramp(t, c["tip"] + 0.3, 1.2)                          # twin slides onto the blue tip
        # corkscrews and the flat sum wave (when time runs)
        cd = corks * (1 - 0.85 * ramp(t, c["mirror"] + 0.2, 1.4))   # corkscrews fade back as we return to the plane
        if cd > 0.01:
            for sgn, col in ((1, BLUEc), (-1, ORANGEc)):
                ang = sgn * (th - TAU2 * back)
                g.add(glow(self.proj(self.W3(xs, r * np.cos(ang), r * np.sin(ang))), col, 2.2, 0.75 * cd))
            g.add(glow(self.proj(self.W3(xs, 2 * r * np.cos(th - TAU2 * back), 0)), INKc, 3.4, cd))
        # 3) mirror line between the tips
        ma = fa * win(t, c["mirrorpair"] + 0.3, c["tip"] + 0.2, 0.8)
        if ma > 0.01 and abs(np.sin(th)) > 0.02:
            g.add(DashedLine(self.P(*e1), self.P(*e2), dash_length=0.07, stroke_color=INKc, stroke_width=3,
                             stroke_opacity=0.8 * ma))
            g.add(Dot(self.P(0, e1[1], 0), radius=0.05, color=INKc).set_opacity(ma))
        # the arrows (orange drawn from the blue tip once added, tip to tail)
        base = e1 * tip
        # nudge apart where they would overlap exactly: on top of each other (before adding),
        # and pointing opposite ways along one line (after adding, at the quarter turn)
        sep = 0.10 * win(t, c["ontop"] + 0.2, c["tip"] + 0.4, 0.6) * (1 - tip)
        ysep = 0.07 * tip * abs(np.sin(th)) ** 8 * (1 - corks)
        d1 = np.array([0, -ysep, sep])
        d2 = np.array([0, ysep, -sep])
        g.add(Line(self.P(*d1), self.P(*(e1 + d1)), stroke_color=BLUEc, stroke_width=6, stroke_opacity=fa))
        g.add(Dot(self.P(*(e1 + d1)), radius=0.06, color=BLUEc).set_opacity(fa))
        if tw_a > 0.01:
            g.add(Line(self.P(*(base + d2)), self.P(*(base + e2 + d2)), stroke_color=ORANGEc,
                       stroke_width=6, stroke_opacity=tw_a))
            g.add(Dot(self.P(*(base + e2 + d2)), radius=0.06, color=ORANGEc).set_opacity(tw_a))
        # labels: +w and -w (fixed spot, colour-coded), until tip to tail
        lab = tw_a * (1 - ramp(t, c["slide"], 0.6))
        if lab > 0.01:
            o = self.P(0, 0, 0)
            for i, (txt, col) in enumerate((("spins +ω", BLUEc), ("spins −ω", ORANGEc))):
                g.add(T(txt, 20, col, BOLD).set_opacity(lab).move_to(o + np.array([-2.6, 0.9 - 0.45 * i, 0])))
        # 5) the sum: a white dot (after tip to tail), the green ups and downs, the real-line track
        sa = fa * ramp(t, c["tip"] + 1.3, 0.6)
        if sa > 0.01:
            tot = e1 + e2
            ga = fa * ramp(t, c["opp"] + 0.6, 0.6) * (1 - corks)
            if ga > 0.01 and abs(e1[2]) > 0.03:
                g.add(DashedLine(self.P(0, e1[1], 0), self.P(*e1), dash_length=0.07, stroke_color=GOODc,
                                 stroke_width=5, stroke_opacity=ga))
                g.add(DashedLine(self.P(0, tot[1], e1[2]), self.P(*tot), dash_length=0.07, stroke_color=GOODc,
                                 stroke_width=5, stroke_opacity=ga))
                g.add(T("up", 18, GOODc, BOLD).set_opacity(ga).move_to(self.P(0, e1[1], e1[2] / 2) + LEFT * 0.35))
                g.add(T("down", 18, GOODc, BOLD).set_opacity(ga).move_to(self.P(0, tot[1], e1[2] / 2) + RIGHT * 0.5))
            tr = fa * ramp(t, c["slide"] + 1.0, 1.0)
            if tr > 0.01:
                g.add(Line(self.P(0, -2 * r, 0), self.P(0, 2 * r, 0), stroke_color=INKc, stroke_width=10,
                           stroke_opacity=0.3 * tr))
                g.add(T("cos ωt", 20, INKc, BOLD).set_opacity(tr * (1 - corks))
                      .move_to(self.P(0, 2 * r, 0) + DOWN * 0.4 + RIGHT * 0.2))
            g.add(Dot(self.P(*tot), radius=0.1, color=INKc).set_opacity(sa))

    def label(self, g, p3, text, color, a):
        """a short label pinned to a 3D point (drawn flat, facing the camera)"""
        if a > 0.02:
            g.add(T(text, 20, color, BOLD).set_opacity(a).move_to(self.P(*p3)))

    def axis_labels(self, g, a, t):
        """'real' along +Re and 'imaginary' along +Im, at a fixed screen distance from the origin"""
        o = self.P(0, 0, 0)
        for d3, text, col, dist in (((0, 0.3, 0), "real", BLUEc, 2.15), ((0, 0, 0.3), "imaginary", GOODc, 1.9)):
            v = self.P(*d3) - o
            n = np.linalg.norm(v[:2])
            if n < 0.05:                       # axis pointing at the camera: no label
                continue
            k = 1 + 0.68 * win(t, SC["two"]["start"] + 0.6, C["two"]["time"] + 1.4, 1.6)  # follow the close-up
            pos = o + v / n * dist * k
            pos[0] = np.clip(pos[0], -FW / 2 + 1.0, FW / 2 - 1.0)
            pos[1] = np.clip(pos[1], -FH / 2 + 1.2, FH / 2 - 2.5)
            g.add(T(text, 20, col, BOLD).set_opacity(0.9 * a).move_to(pos))

    def endness(self):
        """1 when looking straight down the time axis."""
        return float(np.clip(1 - abs(self.basis[2][0] - 1) * 6, 0, 1))

    def parts_overlay(self, t, g, v, mid, a):
        c = C["parts"]
        o = self.P(mid, 0, 0)
        ca_ = ramp(t, c["coords"] + 0.2, 0.6) * a
        if ca_ > 0.01:      # real part across (blue), imaginary part up/down (green)
            px, py = self.P(mid, v.real, 0), self.P(mid, v.real, v.imag)
            g.add(Line(o, px, stroke_color=BLUEc, stroke_width=8, stroke_opacity=ca_))
            g.add(DashedLine(px, py, dash_length=0.08, stroke_color=GOODc, stroke_width=5, stroke_opacity=ca_))
            g.add(T("Re", 22, BLUEc, BOLD).set_opacity(ca_).move_to((o + px) / 2 + UP * 0.28))
            g.add(T("Im", 22, GOODc, BOLD).set_opacity(ca_).move_to((px + py) / 2 + RIGHT * 0.4))
        pa = ramp(t, c["polar"] + 0.2, 0.6) * a
        if pa > 0.01:       # the length: what the spectrum shows
            g.add(Line(o, self.P(mid, v.real, v.imag), stroke_color=INKc, stroke_width=4, stroke_opacity=0.9 * pa))
        aa = ramp(t, c["angle"] + 0.2, 0.6) * a
        if aa > 0.01:       # the angle: the phase
            ang = np.angle(v)
            th = np.linspace(0, ang, 40)
            rr = 0.5 * abs(v)
            g.add(poly(self.proj(self.W3(mid, rr * np.cos(th), rr * np.sin(th))), ORANGEc, 4, aa))

    # -------------------------------------------------------------- 2D panels
    def spectrum_axes(self, g, box, xr, a, ticks):
        x0, y0, x1, y1 = box
        X = lambda f: x0 + (f - xr[0]) / (xr[1] - xr[0]) * (x1 - x0)
        g.add(Line([x0, y0, 0], [x1, y0, 0], stroke_color=AXc, stroke_width=2, stroke_opacity=a))
        for f, s in ticks:
            g.add(T(s, 18, MUTEDc).set_opacity(a).move_to([X(f), y0 - 0.22, 0]))
        return X

    def two_panel(self, t, g):
        c, s = C["two"], SC["two"]
        a = win(t, c["mirror"], s["end"] - 0.4, 0.8)
        if a < 0.01:
            return
        box = (1.8, -1.9, 6.6, 0.9)
        X = self.spectrum_axes(g, box, (-2.6, 2.6), a, [(-2, "−2X"), (-1, "−1X"), (0, "0"), (1, "1X"), (2, "2X")])
        H = lambda v: box[1] + v * 2.2
        fold = ramp(t, c["fold"] + 0.3, 1.6)
        # +f bar grows by the folded copy; -f bar slides over and stacks on top
        g.add(Line([X(1), box[1], 0], [X(1), H(0.5), 0], stroke_color=BLUEc, stroke_width=22, stroke_opacity=a))
        xm = X(-1) + (X(1) - X(-1)) * fold
        ybase = box[1] + (H(0.5) - box[1]) * fold
        g.add(Line([xm, ybase, 0], [xm, ybase + 0.5 * 2.2, 0], stroke_color=ORANGEc, stroke_width=22,
                   stroke_opacity=a * (1 - 0.35 * fold)))
        if fold > 0.98:
            g.add(Line([X(1), box[1], 0], [X(1), H(1.0), 0], stroke_color=BLUEc, stroke_width=22, stroke_opacity=a))
        # a phase clock over each bar: same size, opposite angle (they turn with the arrows)
        ka = a * ramp(t, c["mirror"] + 1.0, 0.8) * (1 - ramp(t, c["fold"], 0.6))
        if ka > 0.01:
            th = theta2(t)
            for f, sgn, col in ((1, 1, BLUEc), (-1, -1, ORANGEc)):
                cc = np.array([X(f), H(0.5) + 0.75, 0])
                g.add(Circle(radius=0.36, stroke_color=MUTEDc, stroke_width=2, stroke_opacity=ka).move_to(cc))
                g.add(Line(cc, cc + 0.33 * np.array([np.cos(sgn * th), np.sin(sgn * th), 0]), stroke_color=col,
                           stroke_width=5, stroke_opacity=ka))
        ha = a * win(t, c["mirror"] + 0.4, c["fold"], 0.6)
        if ha > 0.01:
            for f in (1, -1):
                g.add(T("½", 22, INKc, BOLD).set_opacity(ha).move_to([X(f) + 0.42, H(0.25), 0]))

    def wind_panel(self, t, g):
        s, c = SC["wind"], C["wind"]
        a = win(t, c["dial"], SC["parts"]["end"] - 0.5, 0.8)
        if a < 0.01:
            return
        box = (2.3, -2.25, 6.8, 0.4)
        X = self.spectrum_axes(g, box, (0.2, 4.5), a, [(1, "1X"), (2, "2X"), (3, "3X"), (4, "4X")])
        top = SPEC_TRACE.max() * 1.15
        H = lambda v: box[1] + v / top * (box[3] - box[1])
        fw = dial(t)
        upto = FW_GRID <= max(fw, 0.31) if t < SC["parts"]["start"] else np.ones_like(FW_GRID, bool)
        pts = np.stack([[X(f) for f in FW_GRID[upto]], [H(v) for v in SPEC_TRACE[upto]], np.zeros(upto.sum())], 1)
        if len(pts) > 1:
            g.add(glow(pts, ORANGEc, 2.6, a))
        # needle at the current winding speed
        g.add(DashedLine([X(fw), box[1], 0], [X(fw), box[3], 0], dash_length=0.07, stroke_color=INKc,
                         stroke_width=2, stroke_opacity=0.7 * a))
        pa = ramp(t, C["parts"]["polar"] + 0.2, 0.6) * a
        if pa > 0.01:      # the 2X peak lights up: same length as the arrow
            v = 2 * abs(com(2.0))
            g.add(Line([X(2), box[1], 0], [X(2), H(v), 0], stroke_color=INKc, stroke_width=6, stroke_opacity=pa))

    def hook(self, t, g):
        c = C["hook"]
        a = ramp(t, c["three"], 0.6) * (1 - ramp(t, SC["arrow"]["start"] - 0.4, 0.7))
        if a < 0.01:
            return
        col = ramp(t, c["collapse"] + 0.2, 1.4)
        tt = np.linspace(0, 2, 500)
        for i, (ph, colr) in enumerate(((PH_SQUARE, INKc), (PH_SPIKE, BLUEc), (PH_NOISE, ORANGEc))):
            draw = ramp(t, c["three"] + 0.3 * i, 1.4)
            n = max(2, int(len(tt) * draw))
            y0 = (2.15, 0.35, -1.5)[i]
            pts = np.stack([-4.4 + tt[:n] * 2.75, y0 + 0.4 * odd_sum(tt[:n], ph), np.zeros(n)], 1)
            g.add(glow(pts, colr, 2.6, a * (1 - 0.45 * col)))
        # the shared spectrum appears on the right
        sa = col * a
        if sa > 0.01:
            box = (2.2, -1.6, 6.6, 1.6)
            X = lambda k: box[0] + (k - 0.3) / 15.4 * (box[2] - box[0])
            for k in range(1, 16):
                if k % 2:
                    h = (4 / (np.pi * k)) / 1.35 * (box[3] - box[1])
                    g.add(Line([X(k), box[1], 0], [X(k), box[1] + h * sa, 0], stroke_color=BLUEc if k == 1 else ORANGEc,
                               stroke_width=14, stroke_opacity=sa))
                if k % 2:
                    g.add(T(f"{k}X", 16, MUTEDc).set_opacity(sa).move_to([X(k), box[1] - 0.22, 0]))
            g.add(Line([box[0] - 0.1, box[1], 0], [box[2] + 0.1, box[1], 0], stroke_color=AXc, stroke_width=2, stroke_opacity=sa))
            for i in range(3):           # three arrows into the one spectrum
                y0 = (2.15, 0.35, -1.5)[i]
                g.add(Arrow([1.35, y0, 0], [2.05, 0.1, 0], buff=0.05, stroke_width=3, color=MUTEDc,
                            max_tip_length_to_length_ratio=0.12).set_opacity(0.8 * sa))

    def shape(self, t, g):
        s, c = SC["shape"], C["shape"]
        a = win(t, s["start"], s["end"] - 0.4, 0.8)
        if a < 0.01:
            return
        # phases: square -> spike -> noise -> square while the clocks turn
        u = (t - c["spin"] - 0.3) / 7.5
        keys = [PH_SQUARE, PH_SPIKE, PH_NOISE, PH_SQUARE]
        if u <= 0:
            ph = PH_SQUARE
        elif u >= 1:
            ph = PH_SQUARE
        else:
            seg = min(int(u * 3), 2)
            w_ = ease(u * 3 - seg)
            # turn each clock the short way round
            d = (keys[seg + 1] - keys[seg] + np.pi) % TAU2 - np.pi
            ph = keys[seg] + w_ * d
        tt = np.linspace(0, 2, 600)
        y = odd_sum(tt, ph)
        pts = np.stack([-4.6 + tt * 5.0, 1.05 + 0.42 * y, np.zeros(len(tt))], 1)
        colr = INKc
        g.add(glow(pts, colr, 3.0, a))
        g.add(Line([-4.6, 1.05, 0], [5.4, 1.05, 0], stroke_color=GRIDc, stroke_width=1.5, stroke_opacity=a))
        ca = ramp(t, c["clocks"] + 0.4, 0.8) * a
        for i, (n, amp, p) in enumerate(zip(ODD, AMP, ph)):
            cx, cy = -4.1 + i * 1.2, -0.75
            if ca > 0.01:
                g.add(Circle(radius=0.36, stroke_color=MUTEDc, stroke_width=2, stroke_opacity=ca).move_to([cx, cy, 0]))
                g.add(Line([cx, cy, 0], [cx + 0.32 * np.cos(p + np.pi / 2), cy + 0.32 * np.sin(p + np.pi / 2), 0],
                           stroke_color=BLUEc if n == 1 else ORANGEc, stroke_width=5, stroke_opacity=ca))
            h = amp / AMP[0] * 1.1
            g.add(Line([cx, -2.5, 0], [cx, -2.5 + h, 0], stroke_color=BLUEc if n == 1 else ORANGEc, stroke_width=16,
                       stroke_opacity=a))
            g.add(T(f"{n}X", 15, MUTEDc).set_opacity(a).move_to([cx, -2.72, 0]))

    def life(self, t, g):
        s, c = SC["life"], C["life"]
        # 1) balancing: a rotor with a heavy spot; the 1X phasor turns with it
        a1 = win(t, c["balance"], c["coupling"] - 0.1, 0.6)
        if a1 > 0.01:
            th = TAU2 * 0.4 * t
            cx, cy, R = -0.8, 0.3, 1.45
            g.add(Circle(radius=R, stroke_color=MUTEDc, stroke_width=4, stroke_opacity=a1).move_to([cx, cy, 0]))
            g.add(Dot([cx, cy, 0], radius=0.08, color=MUTEDc).set_opacity(a1))
            g.add(Dot([cx + 0.95 * R * np.cos(th), cy + 0.95 * R * np.sin(th), 0], radius=0.16, color=BADc).set_opacity(a1))
            g.add(Line([cx + R, cy, 0], [cx + R + 0.35, cy, 0], stroke_color=INKc, stroke_width=5, stroke_opacity=a1))
            px, py = 3.3, 0.3
            g.add(Circle(radius=1.0, stroke_color=MUTEDc, stroke_width=2, stroke_opacity=a1).move_to([px, py, 0]))
            g.add(Arrow([px, py, 0], [px + 0.95 * np.cos(th - 0.6), py + 0.95 * np.sin(th - 0.6), 0], buff=0,
                        color=ORANGEc, stroke_width=6, max_tip_length_to_length_ratio=0.2).set_opacity(a1))
            g.add(Arc(radius=0.55, start_angle=th - 0.6, angle=0.6, arc_center=[px, py, 0], stroke_color=INKc,
                      stroke_width=3, stroke_opacity=0.7 * a1))
        # 2) across a coupling: two bearings, two 1X phasors
        a2 = win(t, c["coupling"], c["resonance"] - 0.1, 0.6)
        if a2 > 0.01:
            th = TAU2 * 0.4 * t
            mis = ramp(t, c["coupling"] + 3.4, 1.2)          # first in step (imbalance), then opposite (misalignment)
            g.add(Line([-4.5, -0.6, 0], [4.5, -0.6, 0], stroke_color=MUTEDc, stroke_width=10, stroke_opacity=a2))
            g.add(Rectangle(width=0.55, height=0.9, stroke_color=INKc, stroke_width=3, fill_color=SURF, fill_opacity=1)
                  .move_to([0, -0.6, 0]).set_opacity(a2))
            for bx, extra in ((-2.6, 0.0), (2.6, np.pi * mis)):
                g.add(Rectangle(width=0.8, height=0.65, stroke_color=INKc, stroke_width=3).move_to([bx, -0.6, 0])
                      .set_stroke(opacity=a2))
                cx, cy = bx, 1.3
                g.add(Circle(radius=0.85, stroke_color=MUTEDc, stroke_width=2, stroke_opacity=a2).move_to([cx, cy, 0]))
                g.add(Arrow([cx, cy, 0], [cx + 0.8 * np.cos(th + extra), cy + 0.8 * np.sin(th + extra), 0], buff=0,
                            color=GOODc if mis < 0.5 else BADc, stroke_width=6,
                            max_tip_length_to_length_ratio=0.2).set_opacity(a2))
        # 3) through a resonance: amplitude peaks, phase swings 0 -> 180 deg, 90 deg at the peak
        a3 = win(t, c["resonance"], s["end"] - 0.4, 0.6)
        if a3 > 0.01:
            r = np.linspace(0.2, 2.2, 300)
            z = 0.12
            amp = 1 / np.sqrt((1 - r ** 2) ** 2 + (2 * z * r) ** 2)
            phs = np.degrees(np.arctan2(2 * z * r, 1 - r ** 2))
            x = -4.2 + (r - 0.2) / 2.0 * 8.4
            ya = -0.1 + amp / amp.max() * 2.2
            yp = -2.6 + phs / 180 * 1.9
            g.add(glow(np.stack([x, ya, np.zeros_like(x)], 1), BLUEc, 2.6, a3))
            g.add(glow(np.stack([x, yp, np.zeros_like(x)], 1), ORANGEc, 2.6, a3))
            g.add(Line([-4.3, -0.1, 0], [4.3, -0.1, 0], stroke_color=AXc, stroke_width=2, stroke_opacity=a3))
            g.add(Line([-4.3, -2.6, 0], [4.3, -2.6, 0], stroke_color=AXc, stroke_width=2, stroke_opacity=a3))
            xpk = -4.2 + (1.0 - 0.2) / 2.0 * 8.4
            g.add(DashedLine([xpk, -2.6, 0], [xpk, 2.2, 0], dash_length=0.08, stroke_color=MUTEDc, stroke_width=2,
                             stroke_opacity=0.8 * a3))
            u = ramp(t, c["resonance"] + 0.6, 4.0)
            i = int(u * (len(r) - 1))
            g.add(Dot([x[i], ya[i], 0], radius=0.09, color=BLUEc).set_opacity(a3))
            g.add(Dot([x[i], yp[i], 0], radius=0.09, color=ORANGEc).set_opacity(a3))
            for deg, lab in ((0, "0°"), (90, "90°"), (180, "180°")):
                g.add(T(lab, 16, MUTEDc).set_opacity(a3).move_to([-4.75, -2.6 + deg / 180 * 1.9, 0]))

    # -------------------------------------------------------------- HUD: title, maths, caption, mascot
    def hud(self, t, g, cur):
        S = SC[cur]
        ta = ramp(t, S["start"] - 0.2, 0.5) * (1 - ramp(t, DUR - 1.4, 0.8))
        if ta > 0.01:
            g.add(T(S["kicker"], 17, ORANGEc, BOLD).set_opacity(ta).move_to(FIG(0.03, 0.966), aligned_edge=LEFT))
            g.add(T(S["title"], 36, INKc, BOLD).set_opacity(ta).move_to(FIG(0.03, 0.905), aligned_edge=LEFT))
        cur_eq = None
        for t0, tex in EQS:
            if t >= t0:
                cur_eq = (t0, tex)
        if cur_eq and t <= EQ_END + 0.4:
            t0, tex = cur_eq
            mob = TEX(tex, 40).move_to(FIG(0.03, 0.805), aligned_edge=LEFT)
            al = (t - t0) / 1.1
            if al < 1:
                an = Write(mob)
                an.begin()
                an.interpolate(max(al, 0.0))
            fade = 1 - ramp(t, EQ_END, 0.4)
            if fade < 1:
                mob.set_opacity(fade)
            g.add(mob)
        for l in LINES:
            if l["start"] - 0.05 <= t <= l["end"]:
                lines = textwrap.wrap(l["text"], 52)
                txt = VGroup(*[T(x, 28, INKc, BOLD) for x in lines]).arrange(DOWN, buff=0.12)
                a = ramp(t, l["start"], 0.25)
                box = RoundedRectangle(corner_radius=0.12, width=txt.width + 0.6, height=txt.height + 0.4,
                                       fill_color="#000000", fill_opacity=0.62 * a, stroke_width=0)
                cap = VGroup(box, txt.set_opacity(a)).move_to(FIG(0.56, 0.075) + DOWN * 0.15 * (1 - a))
                if cap.get_right()[0] > FW / 2 - 0.3:
                    cap.shift(LEFT * (cap.get_right()[0] - (FW / 2 - 0.3)))
                g.add(cap)
                break
        self.mascot(t, g)
        veil = max(1 - ramp(t, 0, 0.6), ramp(t, DUR - 0.8, 0.7))
        if veil > 0.01:
            g.add(Rectangle(width=FW + 1, height=FH + 1, fill_color=SURF, fill_opacity=veil, stroke_width=0))

    def mascot(self, t, g):
        ap = ramp(t, 1.0, 0.5)
        if ap < 0.01:
            return
        base, sc = FIG(0.095, 0.31), 1.45
        Q = lambda x, y: base + np.array([(x - 0.5) * sc, y * sc, 0])
        happy, surprise, excited, dizzy = (level(k, t) for k in ("happy", "surprise", "excited", "dizzy"))
        x = np.linspace(0, 1, 160)
        bob = 0.03 * np.sin(TAU2 * 0.55 * t)
        hop = 0.14 * happy * abs(np.sin(TAU2 * 1.6 * t))
        y = 0.4 * np.sin(TAU2 * x) + bob + hop
        if dizzy > 0:      # gets wound up during the winding machine
            y = y + 0.06 * dizzy * np.sin(TAU2 * 3 * x + 9 * t)
        y = y * ap
        body = np.array([Q(a, b) for a, b in zip(x, y)])
        g.add(poly(body, BLUEc, 32, 0.12 * ap), poly(body, BLUEc, 13, ap))
        r = 0.095 * (1 + 0.25 * excited + 0.35 * surprise)
        ey = 0.4 * np.sin(TAU2 * np.array([0.15, 0.35])) + bob + hop + 0.17
        blink = 0.12 if ((t + 0.7) % 3.6) < 0.13 else 1.0
        gx, gy = (0.95, 0.1) if surprise > 0.3 else (0.75, 0.45)
        if dizzy > 0.3:
            gx, gy = np.cos(6 * t), np.sin(6 * t)
        gn = np.hypot(gx, gy)
        for xe, yv in zip((0.15, 0.35), ey):
            c0 = Q(xe, yv * ap)
            if happy > 0.5:
                g.add(poly([Q(xe - 0.09, yv - 0.03), Q(xe, yv + 0.045), Q(xe + 0.09, yv - 0.03)], INKc, 6, ap))
                continue
            g.add(Ellipse(width=2 * r * sc, height=2 * r * blink * sc, fill_color=INKc, fill_opacity=ap, stroke_width=0).move_to(c0))
            if blink > 0.3:
                pr = r * (0.42 if surprise < 0.5 else 0.3)
                g.add(Circle(radius=pr * sc, fill_color=SURF, fill_opacity=ap, stroke_width=0)
                      .move_to(c0 + np.array([0.45 * r * gx / gn * sc, 0.45 * r * gy / gn * sc, 0])))
        my = (0.4 * np.sin(TAU2 * 0.25) + bob + hop - 0.2) * ap
        mc = Q(0.25, my)
        if surprise > 0.4:
            g.add(Ellipse(width=0.09 * sc, height=0.12 * sc, fill_color=INKc, fill_opacity=ap, stroke_width=0).move_to(mc))
        else:
            cv = 0.05 + 0.07 * happy - 0.06 * dizzy
            s_ = np.linspace(-1, 1, 16)
            g.add(poly([mc + np.array([0.09 * a_ * sc, cv * a_ ** 2 * sc, 0]) for a_ in s_], INKc, 5, ap))
        for t0, d, txt in BUBBLES:
            if t0 <= t <= t0 + d:
                a = win(t, t0, t0 + d, 0.3)
                lines = textwrap.wrap(txt, 15)
                tx = VGroup(*[T(s, 20, INKc, BOLD) for s in lines]).arrange(DOWN, buff=0.08)
                box = RoundedRectangle(corner_radius=0.12, width=tx.width + 0.4, height=tx.height + 0.3,
                                       fill_color="#1d1d1b", fill_opacity=0.95 * a, stroke_color=BLUEc,
                                       stroke_width=3, stroke_opacity=a)
                g.add(VGroup(box, tx.set_opacity(a)).move_to(FIG(0.105, 0.56)))
                break
