# The half of the FFT your analyser throws away: the code

Python + [Manim Community](https://www.manim.community/) (v0.22). One timeline drives the animation,
the captions, the mascot and the sound, so they stay in sync.

| File | What it does |
|---|---|
| `captions_fft.py` | The story: scenes, captions and cue times. Writes `timeline_fft.json`. |
| `fft_story.py` | Draws every frame: the rotating arrow and its corkscrew, the two counter-rotating arrows, the winding machine, real and imaginary parts, the phase clocks, the field examples. |
| `fft_sound.py` | The soundtrack, generated in NumPy on the timeline's cues. |
| `hook_image.py` | The "same spectrum" figure: three signals with identical harmonic amplitudes and different phases (it checks the spectra really are identical). |

## Run it

Needs Python 3.10+, `pip install manim numpy scipy matplotlib soundfile`, ffmpeg and LaTeX.

```bash
python captions_fft.py                               # 1. timeline
manim -qh fft_story.py FFTStory -o fft.mp4           # 2. video (PREVIEW=1 and -ql for a quick look)
python fft_sound.py                                  # 3. soundtrack -> fft_sound.wav
ffmpeg -i media/videos/fft_story/1080p60/fft.mp4 -i fft_sound.wav \
       -map 0:v -map 1:a -c:v copy -c:a aac -shortest fft-phase.mp4
```

To render a slice, set `T0` and `T1` in seconds, e.g. `T0=60 T1=110 manim -qh fft_story.py FFTStory -o part.mp4`.

Made by Muhammad Yasir · https://nodallab.dev
