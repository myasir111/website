"""The half of the FFT your analyser throws away: script and timing.

Scenes (key, title, kicker, lines). Cue tags [x] mark when things happen;
{+s} adds a pause after a line. Writes timeline_fft.json.
"""
import json, re

SCENES = [
    ("hook", "Three signals, one spectrum", "THE PUZZLE", [
        "[three] Three very different signals…",
        "[collapse] …and the analyser shows the same spectrum for all three. {+1.2}",
        "Same peaks, same heights. So where did the shape go? {+0.6}",
    ]),
    ("arrow", "Every frequency is an arrow", "PART 1", [
        "[circle] Start with one frequency: an arrow going round a circle. {+0.6}",
        "[helix] Let time run backwards into the page and the tip draws a corkscrew. {+1.2}",
        "[real] Its shadow on the floor is a cosine: the real part. {+0.8}",
        "[imag] Its shadow on the back wall is a sine: the imaginary part. {+0.8}",
        "One arrow, two shadows: e to the iωt. {+0.4}",
    ]),
    ("two", "Why half the FFT is a mirror", "PART 2", [
        "[pair] A real vibration is two arrows, spinning in opposite directions. {+1.0}",
        "[sum] Their sideways parts cancel. What's left moves only up and down. {+1.2}",
        "[mirror] So every peak appears twice: at +f and at −f, a mirror image. {+0.8}",
        "[fold] Analysers drop the mirror half and double the rest. {+0.6}",
    ]),
    ("wind", "The winding machine", "PART 3", [
        "[wrap] Now take the machine signal and wrap it around a circle. {+0.6}",
        "[dot] Mark its centre of mass. {+0.4}",
        "[dial] Turn the winding speed. Most of the time, the dot hugs the middle… {+2.0}",
        "[hit] …until the speed matches a harmonic. Then it shoots out. {+3.0}",
        "Trace the dot's distance and you've drawn the spectrum. That's what the FFT computes. {+1.0}",
    ]),
    ("parts", "Real and imaginary", "PART 4", [
        "[freeze] Stop the dial at 2X and look at the dot. {+0.4}",
        "[coords] Across: how much cosine. Up and down: how much sine. {+1.0}",
        "[polar] Its distance from the middle is the peak you see. {+0.6}",
        "[angle] Its angle is the phase: when in each turn this harmonic peaks. {+1.0}",
    ]),
    ("shape", "Phase is the shape", "PART 5", [
        "[clocks] Back to the three signals. Give each harmonic a clock for its phase. {+0.8}",
        "[spin] Turn only the clocks. The bars never move… {+2.4}",
        "…but the shape changes completely. The spectrum keeps the sizes and drops the timing. {+1.0}",
    ]),
    ("life", "Why analysts keep the phase", "IN THE FIELD", [
        "[balance] Balancing: the 1X phase tells you where the heavy spot is. {+1.4}",
        "[coupling] Across a coupling, a phase flip of about 180° is a classic sign of misalignment. {+1.6}",
        "Why phase can tell imbalance from misalignment is a story for another video. {+0.6}",
        "[resonance] Through a resonance, the phase swings by about 180°, passing 90° at the natural frequency. {+1.6}",
        "[close] Size tells you how much. Phase tells you where and why. {+1.4}",
    ]),
]

LEAD_IN = 0.8
SCENE_GAP = 1.6


def read_time(text):
    return max(1.9, 0.29 * len(text.split()) + 0.9)


t = LEAD_IN
scenes = []
for key, title, kicker, lines in SCENES:
    sc = {"key": key, "title": title, "kicker": kicker, "start": t, "cues": {}, "lines": []}
    for raw in lines:
        hold = 0.0
        mh = re.search(r"\{\+([\d.]+)\}\s*$", raw)
        if mh:
            hold = float(mh.group(1))
            raw = raw[:mh.start()].rstrip()
        m = re.match(r"\[(\w+)\]\s*(.*)", raw)
        tag, text = (m.group(1), m.group(2)) if m else (None, raw)
        if tag:
            sc["cues"][tag] = t
        d = read_time(text) + hold
        sc["lines"].append({"text": text, "start": t, "end": t + d - 0.12})
        t += d
    t += SCENE_GAP
    sc["end"] = t
    scenes.append(sc)
t += 1.5
json.dump({"duration": t, "scenes": scenes}, open("timeline_fft.json", "w"), indent=1)
print(f"duration {t:.1f} s")
for s in scenes:
    print(f"{s['key']:6s} {s['start']:6.1f} -> {s['end']:6.1f}", {k: round(v - s['start'], 1) for k, v in s['cues'].items()})
