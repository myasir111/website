"""Hook image: three waveforms, one spectrum. Same harmonic amplitudes, different phases."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BG, INK, MUTED, GRID = "#111110", "#f0efec", "#898781", "#2c2c2a"
BLUE, ORANGE = "#3987e5", "#d95926"
N, K = 4096, 15
t = np.arange(N) / N * 2                        # two turns
ks = np.arange(1, K + 1, 2)                     # odd harmonics
amp = 4 / (np.pi * ks)                          # square-wave amplitudes
rng = np.random.default_rng(7)
phases = {
    "square": np.zeros_like(ks, dtype=float),                  # all sines in step
    "spike": np.full(len(ks), np.pi / 2),                      # all cosines: peaks line up
    "noise": rng.uniform(0, 2 * np.pi, len(ks)),               # scrambled
}
cols = [INK, BLUE, ORANGE]
waves = {k: sum(a * np.sin(2 * np.pi * n * t + p) for a, n, p in zip(amp, ks, ph)) for k, ph in phases.items()}

# check: identical amplitude spectra
specs = []
for w in waves.values():
    X = np.abs(np.fft.rfft(w[: N // 2])) / (N // 4)            # one turn -> bin n = nX
    specs.append(X[:17])
assert np.allclose(specs[0], specs[1], atol=1e-9) and np.allclose(specs[0], specs[2], atol=1e-9)

plt.rcParams.update({"font.family": "DejaVu Sans"})
fig = plt.figure(figsize=(10.8, 10.8), dpi=100, facecolor=BG)
for i, (key, c) in enumerate(zip(waves, cols)):
    ax = fig.add_axes([0.07, 0.72 - i * 0.2, 0.86, 0.16], facecolor=BG)
    w = waves[key]
    ax.plot(t, w, color=c, lw=7, alpha=0.12, solid_capstyle="round")
    ax.plot(t, w, color=c, lw=2.6, solid_capstyle="round")
    ax.axhline(0, color=GRID, lw=1)
    ax.set_xlim(0, 2); ax.set_ylim(-2.9, 2.9); ax.axis("off")
# the shared spectrum
ax = fig.add_axes([0.07, 0.06, 0.86, 0.2], facecolor=BG)
X = specs[0]
for n in range(1, 17):
    if X[n] > 1e-3:
        ax.plot([n, n], [0, X[n]], color=BLUE if n == 1 else ORANGE, lw=14, solid_capstyle="butt")
    else:
        ax.plot([n, n], [0, 0.08], color=MUTED, lw=1.2, ls=(0, (2, 2)))
    ax.text(n, -0.14, f"{n}X", color=MUTED, ha="center", va="top", fontsize=13)
ax.axhline(0, color=GRID, lw=1.2)
ax.set_xlim(0.3, 16.7); ax.set_ylim(-0.35, 1.45); ax.axis("off")
# one "=" connecting all three waves to the spectrum, nothing else written on the graphs
fig.text(0.5, 0.285, "=", color=INK, fontsize=54, ha="center", va="center", fontweight="bold")
fig.text(0.5, 0.955, "Same spectrum.", color=INK, fontsize=40, ha="center", va="center", fontweight="bold")
fig.savefig("same_fft_hook.png", facecolor=BG)
print("ok, spectra identical")
