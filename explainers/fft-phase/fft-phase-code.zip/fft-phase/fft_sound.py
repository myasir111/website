"""Soft soundtrack for fft_story.py, in the style of the harmonics video:
quiet e-piano bed, gentle whooshes for camera moves, soft swells and clicks.
No rising pitched tones. Reads timeline_fft.json; writes fft_sound.wav."""
import json
import numpy as np
import soundfile as sf
from scipy.signal import butter, sosfilt

SR = 48000
TL = json.load(open("timeline_fft.json"))
DUR = TL["duration"]
SC = {s["key"]: s for s in TL["scenes"]}
C = {k: s["cues"] for k, s in SC.items()}
N = int((DUR + 2) * SR)
FX = [np.zeros(N), np.zeros(N)]
BED = [np.zeros(N), np.zeros(N)]
rng = np.random.default_rng(5)


def place(t, x, g=1.0, pan=0.0, b=None):
    b = FX if b is None else b
    i = int(t * SR)
    if i >= N or i < 0:
        return
    j = min(i + len(x), N)
    a = (pan + 1) * np.pi / 4
    b[0][i:j] += g * np.cos(a) * x[: j - i]
    b[1][i:j] += g * np.sin(a) * x[: j - i]


def tt(d):
    return np.arange(int(d * SR)) / SR


def bp(x, a, b_):
    return sosfilt(butter(2, [a, b_], "band", fs=SR, output="sos"), x)


def lp(x, fc):
    return sosfilt(butter(2, fc, "low", fs=SR, output="sos"), x)


def midi(m):
    return 440 * 2 ** ((m - 69) / 12)


def swell(f, dur=1.4, attack=0.12):
    t = tt(dur)
    e = np.minimum(t / attack, 1) ** 2 * np.exp(-np.maximum(t - attack, 0) / 0.4)
    air = np.convolve(rng.standard_normal(len(t)), np.ones(24) / 24, "same") * 0.25
    return (np.sin(2 * np.pi * f * t) + air) * e * np.sin(np.pi * np.minimum(t / dur, 1)) ** 0.3


def chord(ms, dur=1.8):
    out = np.zeros(int((dur + 0.4) * SR))
    for i, m in enumerate(ms):
        x = swell(midi(m), dur, 0.15)
        d = int(i * 0.05 * SR)
        out[d: d + len(x)] += x * 0.85 ** i
    return out / len(ms) ** 0.5


def whoosh(dur=1.2):
    t = tt(dur)
    u = t / dur
    x = rng.standard_normal(len(t))
    return (bp(x, 250, 900) * (1 - u) + bp(x, 600, 1800) * u) * np.sin(np.pi * u) ** 2 * 2.2


def click():
    """the soft forward click from the harmonics video"""
    t = tt(0.28)
    f = 1600
    x = (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.008)
         + 0.3 * bp(rng.standard_normal(len(t)), 2000, 6000) * np.exp(-t / 0.004)
         + 0.25 * np.sin(2 * np.pi * f * t) * np.exp(-t / 0.07))
    return x * np.minimum(t / 0.001, 1) * np.clip((0.28 - t) / 0.03, 0, 1)


def pop():
    t = tt(0.09)
    f = 420 * (0.6 + 0.8 * t / 0.09)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.025)


def thump():
    t = tt(1.0)
    f = 70 * np.exp(-t / 0.2) + 40
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.minimum(t / 0.01, 1) * np.exp(-t / 0.3)


def epiano(f, dur=1.3):
    t = tt(dur)
    x = np.sin(2 * np.pi * f * t) + 0.22 * np.sin(4 * np.pi * f * t) * np.exp(-t / 0.25)
    return x * np.minimum(t / 0.008, 1) * np.exp(-t / 0.9) * (1 + 0.08 * np.sin(2 * np.pi * 5 * t))


def bass(f, dur):
    t = tt(dur)
    return (np.sin(2 * np.pi * f * t) + 0.18 * np.sin(4 * np.pi * f * t)) * np.minimum(t / 0.04, 1) \
        * np.exp(-t / (dur * 0.9)) * np.clip((dur - t) / 0.15, 0, 1)


# ---- music bed: D major, 92 bpm, soft e-piano arpeggios over bass
beat = 60 / 92
bar = 4 * beat
CH = [(38, [62, 66, 69, 74]), (35, [59, 62, 66, 71]), (31, [55, 59, 62, 67]), (33, [57, 61, 64, 69])]
t0, ci = 0.3, 0
while t0 < DUR + 1:
    b, notes = CH[ci % 4]
    place(t0, bass(midi(b), 2 * bar), 0.55, 0, BED)
    for k in range(2):
        for j, idx in enumerate([0, 1, 2, 3, 2, 1, 2, 3]):
            place(t0 + k * bar + j * beat / 2 + rng.normal(0, 0.004), epiano(midi(notes[idx])),
                  0.32 * (0.9 if j % 2 == 0 else 0.7), 0.25 if j % 2 else -0.25, BED)
    t0 += 2 * bar
    ci += 1

# ---- effects on the story's cues
place(1.0, pop(), 0.5, -0.6)                                     # mascot appears
h, a, w2, wd, pa, sh, lf = (C[k] for k in ("hook", "arrow", "two", "wind", "parts", "shape", "life"))
for i in range(3):
    place(h["three"] + 0.3 * i, whoosh(1.4), 0.05, -0.3 + 0.3 * i)
place(h["collapse"] + 0.2, whoosh(1.6), 0.07)
place(h["collapse"] + 1.4, chord([62, 66, 69]), 0.5)             # one spectrum
place(a["circle"] + 0.2, swell(midi(62), 1.6), 0.35)
place(a["helix"] + 0.3, whoosh(2.4), 0.08)                       # camera swings round
place(a["real"] + 0.2, swell(midi(57), 1.4), 0.25, -0.4)          # floor shadow
place(a["imag"] + 0.2, swell(midi(62), 1.4), 0.25, 0.4)           # wall shadow
# scene "two", step by step (times match fft_story.theta2 and twins())
place(SC["two"]["start"] - 0.3, whoosh(1.8), 0.06)                # camera turns to face the plane
place(w2["twin"] + 0.2, pop(), 0.35, 0.3)                         # the twin appears
place(w2["mirrorpair"] + 0.3, swell(midi(62), 1.4), 0.22)         # mirror line
place(w2["ontop"] + 0.2, click(), 0.1)                            # arrows come to rest on top of each other
place(w2["tip"] + 0.3, whoosh(1.2), 0.05)                         # twin slides onto the tip
place(w2["tip"] + 1.4, chord([62, 69]), 0.4)                      # one arrow, twice as long
place(w2["opp"] + 1.6, swell(midi(50), 1.6), 0.3)                 # quarter turn lands: they cancel
place(w2["slide"] + 0.4, swell(midi(57), 1.4), 0.2)               # spinning again, sliding on the real line
place(w2["time"] + 0.2, whoosh(2.6), 0.07)                        # camera swings round: corkscrews
place(w2["mirror"] - 0.2, whoosh(2.0), 0.06)                      # back to the plane
place(w2["mirror"] + 0.4, click(), 0.12)                          # the two bars
place(w2["conj"] + 0.3, swell(midi(62), 1.4), 0.22)               # same size, opposite angle
place(w2["fold"] + 1.8, click(), 0.14)                            # mirror half folds over
place(wd["wrap"] - 0.3, whoosh(3.0), 0.07)                       # camera swings as the wrap starts
place(wd["dot"] + 0.2, pop(), 0.35)
place(wd["dot"] - 0.3, whoosh(1.8), 0.06)
# each time the dial passes a harmonic, the same soft low chord (no rising pitch)
# the dial (same schedule as fft_story.dial): reaches 1X at hit, then sweeps linearly to 4.4X
c = C["wind"]
a_, hit, end = c["dial"] + 0.4, c["hit"] + 1.0, SC["wind"]["end"] - 1.2
for n in (1, 2, 3, 4):
    tn = hit + (n - 1.0) / 3.4 * (end - hit)
    place(tn - 0.1, chord([50, 57, 62], 1.6), 0.45)
place(pa["freeze"] + 0.2, whoosh(1.8), 0.06)                      # zoom in on the dot
for k in ("coords", "polar", "angle"):
    place(pa[k] + 0.3, click(), 0.1)
place(sh["clocks"] + 0.4, swell(midi(62), 1.4), 0.25)
place(sh["spin"] + 0.3, whoosh(2.4), 0.05)
for k in ("balance", "coupling", "resonance"):
    place(lf[k] + 0.05, whoosh(1.4), 0.06)
place(lf["coupling"] + 4.0, click(), 0.12)                        # phasors flip to 180 degrees (turn red)
place(lf["resonance"] + 2.33, click(), 0.09)                      # dot crosses 90 deg at the natural frequency
place(lf["close"] + 0.3, chord([50, 57, 62, 66, 69, 74], 2.6), 0.6)

# ---- mix: music bed at a fixed level, effects relative to it, gentle fades
ts = np.arange(N) / SR
fade = np.minimum(1, ts / 2.0) * np.clip((DUR + 0.5 - ts) / 2.5, 0, 1)
bed = np.stack(BED, 1) * fade[:, None]
fx = np.stack(FX, 1)
bed *= 0.02 / np.sqrt(np.mean(bed[int(3 * SR): int((DUR - 3) * SR)] ** 2))
w = int(0.05 * SR)
rms = lambda x: np.sqrt((x.mean(1)[: len(x) // w * w].reshape(-1, w) ** 2).mean(1))
fx *= np.median(rms(bed)[60:-60]) * 10 ** (-4 / 20) / rms(fx).max()    # loudest effect 4 dB under the music
mix = fx + bed
mix = mix / np.max(np.abs(mix)) * 0.9
sf.write("fft_sound.wav", mix, SR)
print("written", round(N / SR, 1), "s")
