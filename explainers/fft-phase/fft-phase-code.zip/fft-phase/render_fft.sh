#!/bin/bash
# Full render in two halves (separate media folders), 1080p30, then join.
cd /home/claude/fft_phase
D=$(python3 -c "import json;print(json.load(open('timeline_fft.json'))['duration'])")
H=$(python3 -c "print(round($D/2, 3))")
rm -rf mA mB && mkdir -p mA mB
T0=0 T1=$H manim -qh --frame_rate 30 --disable_caching --media_dir mA fft_story.py FFTStory -o A.mp4 > mA/log.txt 2>&1 &
T0=$H T1=$D manim -qh --frame_rate 30 --disable_caching --media_dir mB fft_story.py FFTStory -o B.mp4 > mB/log.txt 2>&1 &
wait
printf "file '$PWD/mA/videos/fft_story/1080p60/A.mp4'\nfile '$PWD/mB/videos/fft_story/1080p60/B.mp4'\n" > parts.txt
ffmpeg -v error -y -f concat -safe 0 -i parts.txt -c copy fft_video_only.mp4 && echo JOINED
python3 fft_sound.py
J=$(ffmpeg -hide_banner -i fft_sound.wav -af loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
g(){ echo "$J" | python3 -c "import json,sys;print(json.load(sys.stdin)['$1'])"; }
ffmpeg -v error -y -i fft_sound.wav -af "loudnorm=I=-16:TP=-1.5:LRA=11:measured_I=$(g input_i):measured_TP=$(g input_tp):measured_LRA=$(g input_lra):measured_thresh=$(g input_thresh):offset=$(g target_offset):linear=true" -ar 48000 fft_sound_norm.wav
ffmpeg -v error -y -i fft_video_only.mp4 -i fft_sound_norm.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest fft_phase_story.mp4 && echo MUXED
