"""
'Wiggle': an original wave mascot for the 3D harmonics video.

Its body IS the waveform currently on screen (one period), so it turns into a
square, a sawtooth, a triangle, gets clamped, goes messy, and finally becomes
a sine again. It blinks, bobs, watches the action, and reacts:

  appear    pops in at the start                          (pop)
  excited   big eyes when the lanes appear                (ooh chirp)
  surprise  wide eyes + 'o' mouth: even lanes are empty   (huh? chirp)
  happy     ^^ eyes, bounce, confetti at the spectrum     (boing + sparkles)
  slam      a clamp bar slams up and clips its bottom     (clank) + shake
  dizzy     stars circle its head on the messy signal     (warble)
  wink      at the very end                               (sparkle)

Speech bubbles carry its comments. Everything is driven by the same
timeline as the animation; sfx reads Mascot.events for its sounds.
"""
import numpy as np
import matplotlib.pyplot as plt

BLUE, ORANGE, INK, INK2, MUTED = "#3987e5", "#d95926", "#f0efec", "#c3c2b7", "#898781"
SURFACE, PANEL, PUPIL = "#111110", "#1d1d1b", "#111110"
GOOD = "#0ca30c"


def ease(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def ramp(t, t0, d=0.4):
    return float(ease((t - t0) / d))


def window(t, t0, dur, fade=0.25):
    """1 inside [t0, t0+dur] with soft edges."""
    return min(ramp(t, t0, fade), 1 - ramp(t, t0 + dur - fade, fade))


def back_out(x):
    x = np.clip(x, 0, 1)
    c = 1.9
    return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2


class Mascot:
    def __init__(self, e):
        self.e = e
        SC = e.SC
        sq = SC["square"]
        self.SC = SC
        x = np.linspace(0, 1, 400)
        self.x = x
        # one period of every waveform, normalised to [-1, 1]
        self.shapes = {}
        for key, ex in e.EX.items():
            y = ex.full(x)
            y = y - (y.max() + y.min()) / 2
            self.shapes[key] = y / (np.abs(y).max() + 1e-9)
        self.sine = np.sin(2 * np.pi * x)

        intro, messy, why, pay = SC["intro"], SC["messy"], SC["why"], SC["payoff"]
        build_done = max(e.BUILD.values()) + 1.1
        close = SC["build"]["c"]["close"]
        self.t_close = close
        # ---- expression / action schedule  (kind, start, duration)
        self.events = [
            ("appear", 0.9, 0.6),
            ("happy", intro["c"]["side"] + 2.0, 2.4),
            ("dizzy", messy["start"] + 0.3, 3.0),
            ("surprise", messy["c"]["side"] + 1.8, 2.8),
            ("excited", why["c"]["lanes"] + 1.0, 3.2),
            ("surprise", sq["c"]["empty"] + 0.2, 2.6),
            ("happy", sq["c"]["side"] + 2.0, 3.0),
            ("confetti", sq["c"]["side"] + 2.0, 1.9),
            ("slam", SC["cut"]["start"] + 0.05, 0.5),
            ("happy", pay["c"]["side"] + 2.0, 3.0),
            ("confetti", pay["c"]["side"] + 2.0, 1.9),
            ("happy", build_done, 2.0),
            ("wink", close + 3.2, 0.9),
        ]
        # ---- speech bubbles  (start, duration, text)
        self.bubbles = [
            (intro["c"]["intro"] + 0.3, 2.6, "Hi! I'm a pure sine."),
            (intro["c"]["side"] + 2.2, 2.4, "That's me: one peak!"),
            (messy["start"] + 0.5, 2.4, "Whoa… I feel messy."),
            (messy["c"]["side"] + 1.9, 2.6, "So many peaks?!"),
            (why["c"]["lanes"] + 2.2, 2.2, "Only these fit?"),
            (sq["start"] + 0.5, 2.0, "Uh… I'm square now?"),
            (sq["c"]["empty"] + 0.3, 2.8, "Wait… where did the evens go?!"),
            (sq["c"]["side"] + 2.3, 2.4, "That's my spectrum!"),
            (SC["sawtooth"]["start"] + 0.5, 1.8, "Ooh, sharp."),
            (SC["triangle"]["start"] + 0.5, 2.2, "Pointy… but smoother."),
            (SC["cut"]["start"] + 0.35, 1.6, "Ow!"),
            (SC["cut"]["c"]["dc"] + 0.3, 2.4, "That flat bit? My offset."),
            (pay["start"] + 0.5, 2.2, "Messy again…"),
            (pay["c"]["side"] + 2.2, 2.4, "…but now I get it!"),
            (build_done + 0.1, 2.0, "Back together!"),
            (close + 3.2, 2.6, "See you in your next spectrum."),
        ]
        if "sym" in SC:
            y = SC["sym"]["c"]
            self.events += [("happy", y["match"] + 0.4, 2.2), ("surprise", y["verdict"] + 0.3, 2.4),
                            ("excited", y["cancel"] + 1.6, 2.0), ("happy", y["sweep3"] + 4.6, 2.4)]
            self.bubbles += [(y["match"] + 0.5, 2.2, "Same shape back!"),
                             (y["cancel"] + 2.1, 2.4, "2X cancels itself!"),
                             (y["sweep3"] + 4.8, 2.6, "Odd adds up, even cancels!")]
            self.events.sort(key=lambda e_: e_[1])
        self.bubbles.sort()
        self.clamp_on = SC["cut"]["start"] + 0.05
        self.clamp_off = SC[e.next_scene("cut")]["start"] - 0.4

        # ---- artists
        fig = e.fig
        self.ax = fig.add_axes([0.0, 0.15, 0.21, 0.32], zorder=15)
        self.ax.set_axis_off()
        self.fx = fig.add_axes([0, 0, 1, 1], zorder=16)      # confetti, full frame
        self.fx.set_axis_off()
        self.bubble = fig.text(0.105, 0.56, "", fontsize=22, color=INK,
                               fontweight="bold", va="center", ha="center", linespacing=1.25,
                               zorder=17,
                               bbox=dict(boxstyle="round,pad=0.5", facecolor=PANEL,
                                         edgecolor=BLUE, linewidth=2))
        rng = np.random.default_rng(4)
        n = 46
        self.conf = dict(vx=rng.uniform(-0.05, 0.32, n), vy=rng.uniform(0.25, 0.75, n),
                         c=rng.choice([BLUE, ORANGE, INK, GOOD], n),
                         m=rng.choice(["s", "o", "D", "^"], n),
                         s=rng.uniform(5, 11, n), spin=rng.uniform(0, 6, n))
        self.base_pos = e.ax.get_position().bounds

    # ------------------------------------------------------------ helpers
    def level(self, kind, t):
        v = 0.0
        for k, t0, d in self.events:
            if k == kind:
                v = max(v, window(t, t0, d))
        return v

    def start_of(self, kind, t):
        last = None
        for k, t0, d in self.events:
            if k == kind and t0 <= t:
                last = t0
        return last

    def body_shape(self, t):
        e = self.e
        prev, cur, m = e.active_ex(t)
        y = (1 - m) * self.shapes[prev] + m * self.shapes[cur]
        back = ramp(t, self.t_close + 0.6, 1.2)          # ends as a sine again
        return (1 - back) * y + back * self.sine

    # ------------------------------------------------------------ draw
    def draw(self, t):
        ax = self.ax
        ax.cla()
        ax.set_axis_off()
        ax.set_xlim(-0.2, 1.2)
        ax.set_ylim(-0.95, 1.25)
        ax.set_aspect("equal")
        x = self.x

        appear = self.start_of("appear", t)
        if appear is None:
            self._bubble(t)
            return
        pop = back_out((t - appear) / 0.5)
        happy = self.level("happy", t)
        surprise = self.level("surprise", t)
        excited = self.level("excited", t)
        dizzy = self.level("dizzy", t)

        # body: shape + idle bob + squash/stretch
        A = 0.42
        y = A * self.body_shape(t)
        bob = 0.03 * np.sin(2 * np.pi * 0.55 * t)
        hop = 0.0
        if happy > 0:
            ts = self.start_of("happy", t)
            hop = 0.16 * happy * abs(np.sin(2 * np.pi * 1.6 * (t - ts)))
        wob = 0.0
        if dizzy > 0:
            y = y + 0.05 * dizzy * np.sin(2 * np.pi * 3 * x + 9 * t)
            wob = 0.04 * dizzy * np.sin(7 * t)
        squash = 1.0
        ts = self.start_of("slam", t)
        if ts is not None and t - ts < 0.6:
            squash = 1 - 0.25 * np.exp(-(t - ts) / 0.12) * np.cos(25 * (t - ts))
        yy = (y * squash + bob + hop) * pop
        xx = 0.5 + (x - 0.5) * pop + wob

        # clamp bar (cut example): slams up and clips the bottom
        cl = 0.0
        if self.clamp_on - 0.05 <= t:
            up = back_out((t - self.clamp_on) / 0.25)
            down = ramp(t, self.clamp_off, 0.4)
            cl = up * (1 - down)
        if cl > 0:
            top = -0.95 + (0.95 - A - 0.07 + bob + hop) * cl
            ax.add_patch(plt.Rectangle((-0.12, -0.95), 1.24, top + 0.95,
                                       facecolor="#3a3936", edgecolor=MUTED,
                                       lw=2, zorder=3))
            for xs in np.linspace(-0.05, 1.05, 7):
                ax.plot([xs, xs + 0.08], [top - 0.02, top - 0.12], color=MUTED,
                        lw=1.5, zorder=4)

        ax.plot(xx, yy, color=BLUE, lw=34, alpha=0.12, solid_capstyle="round", zorder=5)
        ax.plot(xx, yy, color=BLUE, lw=13, solid_capstyle="round", zorder=6)

        # face rides on the curve around x = 0.25 (the first hump of a sine)
        xe = np.array([0.15, 0.35])
        ye_body = np.interp(xe, x, yy / max(pop, 1e-3)) * pop
        r = 0.095 * pop * (1 + 0.22 * excited + 0.35 * surprise)
        eye_y = ye_body + 0.17 * pop
        exe = 0.5 + (xe - 0.5) * pop + wob
        blink = 1.0
        ph = (t + 0.7) % 3.6
        if ph < 0.13:
            blink = 0.12
        wink = self.level("wink", t)

        # gaze: toward the 3D scene (up-right), lanes when surprised, spin if dizzy
        gx, gy = 0.75, 0.45
        if surprise > 0:
            gx, gy = 0.95, 0.1
        if dizzy > 0.3:
            ang = 6 * t
            gx, gy = np.cos(ang), np.sin(ang)
        g = np.hypot(gx, gy)
        px, py = gx / g, gy / g

        th = np.linspace(0, 2 * np.pi, 40)
        for i, (ex_, ey_) in enumerate(zip(exe, eye_y)):
            if happy > 0.5:                              # ^ ^ happy eyes
                ax.plot(ex_ + r * np.array([-0.9, 0, 0.9]),
                        ey_ + r * np.array([-0.3, 0.45, -0.3]),
                        color=INK, lw=5, solid_capstyle="round", zorder=8)
                continue
            b = blink if not (i == 0 and wink > 0.4) else 0.1
            ax.fill(ex_ + r * np.cos(th), ey_ + r * b * np.sin(th), color=INK, zorder=7)
            if b > 0.3:
                pr = r * (0.42 if surprise < 0.5 else 0.3)
                ax.fill(ex_ + 0.45 * r * px + pr * np.cos(th),
                        ey_ + 0.45 * r * py * b + pr * b * np.sin(th),
                        color=PUPIL, zorder=8)
                ax.plot([ex_ + 0.45 * r * px + pr * 0.35], [ey_ + 0.45 * r * py + pr * 0.4],
                        "o", color=INK, ms=3, zorder=9)          # catch-light
            else:
                ax.plot(ex_ + r * np.array([-0.9, 0.9]), [ey_, ey_], color=INK,
                        lw=4, solid_capstyle="round", zorder=8)

        # mouth under the curve
        mx = 0.5 + (0.25 - 0.5) * pop + wob
        my = np.interp(0.25, x, yy / max(pop, 1e-3)) * pop - 0.2 * pop
        if surprise > 0.4:
            ax.fill(mx + 0.045 * np.cos(th), my + 0.06 * np.sin(th), color=INK, zorder=8)
        else:
            curve = 0.05 + 0.07 * happy - 0.06 * dizzy
            s_ = np.linspace(-1, 1, 20)
            ax.plot(mx + 0.09 * s_ * pop, my + curve * s_ ** 2 * pop,
                    color=INK, lw=4, solid_capstyle="round", zorder=8)

        # dizzy stars circling above its head
        if dizzy > 0.05:
            for i in range(3):
                a = 4 * t + i * 2 * np.pi / 3
                sx = 0.25 + 0.26 * np.cos(a)
                sy = eye_y.max() + 0.25 + 0.07 * np.sin(a)
                ax.plot([sx], [sy], marker="*", ms=16, color="#eda100",
                        alpha=dizzy, zorder=10)

        self._confetti(t)
        self._bubble(t)
        self._shake(t)

    def _confetti(self, t):
        fx = self.fx
        fx.cla()
        fx.set_axis_off()
        fx.set_xlim(0, 1)
        fx.set_ylim(0, 1)
        ts = self.start_of("confetti", t)
        if ts is None or t - ts > 1.9:
            return
        u = t - ts
        c = self.conf
        X = 0.1 + c["vx"] * 0.55 * u
        Y = 0.36 + c["vy"] * u - 0.55 * u ** 2
        a = max(0.0, 1 - u / 1.9)
        for i in range(len(X)):
            fx.plot([X[i]], [Y[i]], marker=c["m"][i], ms=c["s"][i] * (0.8 + 0.2 * np.sin(c["spin"][i] + 9 * u)),
                    color=c["c"][i], alpha=a, mew=0)

    def _bubble(self, t):
        txt, a, lift = "", 0.0, 0.0
        for t0, d, s in self.bubbles:
            if t0 <= t <= t0 + d:
                txt, a = s, window(t, t0, d, 0.15)
                lift = 0.012 * (1 - ramp(t, t0, 0.2))
        import textwrap
        self.bubble.set_text("\n".join(textwrap.wrap(txt, 17)))
        self.bubble.set_visible(bool(txt))
        self.bubble.set_alpha(a)
        self.bubble.get_bbox_patch().set_alpha(0.95 * a)
        self.bubble.set_y(0.56 - lift)

    def _shake(self, t):
        x0, y0, w, h = self.base_pos
        ts = self.start_of("slam", t)
        if ts is not None and 0 <= t - ts < 0.45:
            k = np.exp(-(t - ts) / 0.12)
            dx = 0.006 * k * np.sin(70 * (t - ts))
            dy = 0.005 * k * np.cos(55 * (t - ts))
            self.e.ax.set_position([x0 + dx, y0 + dy, w, h])
        else:
            self.e.ax.set_position([x0, y0, w, h])
