"""
Harmonics, explained in 3D: construct / deconstruct.  Narrated, < 2 min.
1920x1080, 60 fps. Space: x = time, y = harmonic lane (1X..10X), z = amplitude.

Each example: previous sines slide back into the signal, the signal morphs,
then its harmonics peel out one at a time into their lanes. Bars on the
side wall are the spectrum. Timing comes from timeline3d.json.

Render:  python3 examples3d.py out.mp4 [first_frame last_frame]
"""
import json, os, sys, textwrap
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FFMpegWriter

SURFACE = "#111110"
INK, INK2, MUTED = "#f0efec", "#c3c2b7", "#898781"
GRID = "#2c2c2a"
BLUE, ORANGE, GOOD = "#3987e5", "#d95926", "#0ca30c"

FPS = 60
SS = 2                                   # render 2x, downscale (smooth edges)
W, H, DPI = 19.2, 10.8, 100
K = 10
X_LEN = 6.5
N_PTS = 900

TL = json.load(open(os.environ.get("TIMELINE", "timeline_v2.json")))
SILENT = TL.get("voice") is None          # captions carry the story
DURATION = TL["duration"]
SC = {s["key"]: s for s in TL["scenes"]}
for s in TL["scenes"]:
    s["c"] = s["cues"]
    s["L"] = [(l["start"], l["end"]) for l in s["lines"]]

plt.rcParams.update({"font.family": "DejaVu Sans", "text.color": INK,
                     "mathtext.fontset": "cm"})

w0 = 2 * np.pi
tau = np.linspace(0, 2, N_PTS)            # two periods on screen
X = tau / 2 * X_LEN
ks = np.arange(1, K + 1)


def ease(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def ramp(t, t0, d=0.6):
    return float(ease((t - t0) / d))


# ------------------------------------------------------------------ examples
def real_signal(t):
    """A messy but periodic machine signal: imbalance (1X), misalignment (2X)
    and an impact once per revolution that rings and decays."""
    ph = t % 1.0
    tau_ = (ph - 0.32) % 1.0
    ring = np.exp(-tau_ / 0.15) * np.sin(2 * np.pi * 6.0 * tau_)
    y = 0.55 * np.sin(w0 * t) + 0.3 * np.sin(2 * w0 * t + 0.9) + 1.4 * ring
    return y / 1.16


N_FFT = 4096
_t1 = np.arange(N_FFT) / N_FFT


class Example:
    def __init__(self, f, color=INK):
        X_ = np.fft.rfft(f(_t1)) / N_FFT
        self.dc = X_[0].real
        self.a = 2 * X_[1:K + 1].real          # cos
        self.b = -2 * X_[1:K + 1].imag         # sin
        self.amp = np.hypot(self.a, self.b)
        self.amp[self.amp < 0.01] = 0
        self.color = color

    def comps(self, tt):
        ph = w0 * ks[:, None] * tt[None, :]
        return self.a[:, None] * np.cos(ph) + self.b[:, None] * np.sin(ph)

    def full(self, tt):
        return self.dc + self.comps(tt).sum(0)


EX = {
    "sine": Example(lambda t: np.sin(w0 * t), BLUE),
    "square": Example(lambda t: np.sign(np.sin(w0 * t))),
    "sawtooth": Example(lambda t: 2 * ((t + 0.5) % 1) - 1),
    "triangle": Example(lambda t: (2 / np.pi) * np.arcsin(np.sin(w0 * t))),
    "cut": Example(lambda t: np.maximum(np.sin(w0 * t), 0)),
    "real": Example(lambda t: real_signal(t)),
}
SEQ = [s["key"] for s in TL["scenes"]]             # scene order
BUILD_KEY = "build"
ORDER = [k for k in SEQ if k != BUILD_KEY]
PEELERS = [k for k in ORDER if "peel" in SC[k]["c"]]
LAST = PEELERS[-1]                                  # rebuilt at the end


def EXOF(key):
    return EX[SC[key]["ex"]]


# breathing room between scenes: hold, sines slide home, pause, morph
HOME_LEAD, HOME_DUR = 1.6, 1.25
MORPH_DELAY, MORPH_DUR = 0.3, 1.5
MOVE = 0.75                                         # seconds to slide into a lane


def peel_schedule(key):
    """global time each nonzero harmonic starts moving out to its lane."""
    s = SC[key]
    t0 = s["c"]["peel"]
    ex = EXOF(key)
    ks_on = [k for k in ks if ex.amp[k - 1] > 0]
    if key == "payoff":
        # follow the caption: 1X, then 2X, then the impact band, then the rest
        groups = [([1], 0.5), ([2], 1.7), ([4, 5, 6, 7], 3.0), ([3, 8, 9, 10], 5.0)]
        out = {}
        for ks_g, dt in groups:
            for i, k in enumerate(ks_g):
                if k in ks_on:
                    out[k] = t0 + dt + 0.25 * i
        return out
    nxt = [l0 for (l0, _) in s["L"] if l0 > t0 + 0.1]
    t1 = (nxt[0] if nxt else s["end"]) - 0.4
    start = t0 + (1.2 if key == "square" else 0.5)
    step = min(0.85, (t1 - start - 0.7) / max(len(ks_on) - 1, 1))
    return {k: start + i * step for i, k in enumerate(ks_on)}


PEEL = {k: peel_schedule(k) for k in PEELERS}


def build_schedule():
    s = SC[BUILD_KEY]
    t0 = s["c"]["build"] + 0.3
    ks_on = [k for k in ks if EXOF(LAST).amp[k - 1] > 0]
    return {k: t0 + i * 0.55 for i, k in enumerate(reversed(ks_on))}


BUILD = build_schedule()


def next_scene(key):
    i = SEQ.index(key)
    return SEQ[i + 1] if i + 1 < len(SEQ) else None


def moved(key, k, t):
    """0 = inside the signal (front lane), 1 = out in its own lane."""
    if key not in PEEL or k not in PEEL[key]:
        return 0.0
    m = ramp(t, PEEL[key][k], MOVE)
    if key == LAST:
        m *= 1 - ramp(t, BUILD[k], MOVE)
    else:
        m *= 1 - ramp(t, SC[next_scene(key)]["start"] - HOME_LEAD, HOME_DUR)
    return m


def active(t):
    """(previous scene, current scene, morph progress) at time t."""
    if t >= SC[BUILD_KEY]["start"]:
        return LAST, LAST, 1.0
    cur = ORDER[0]
    for key in ORDER[1:]:
        if t >= SC[key]["start"] + 0.05:
            cur = key
    i = ORDER.index(cur)
    if i == 0:
        return cur, cur, 1.0
    prev = ORDER[i - 1]
    return prev, cur, ramp(t, SC[cur]["start"] + MORPH_DELAY, MORPH_DUR)


def active_ex(t):
    p, c, m = active(t)
    return SC[p]["ex"], SC[c]["ex"], m


def _flash_events():
    ev = {k: [] for k in ks}
    for key in PEELERS:
        for k, t0 in PEEL[key].items():
            ev[k].append(t0 + 0.15)
    for k, t0 in BUILD.items():
        ev[k].append(t0 + 0.4)
    if "why" in SC and "lanes" in SC["why"]["c"]:
        lanes = SC["why"]["c"]["lanes"] + 1.2
        for k in ks:
            ev[k].append(lanes + 0.12 * k)
    return ev


FLASH = _flash_events()


def flash(k, t):
    v = 0.0
    for t0 in FLASH[k]:
        if 0 <= t - t0 < 1.5:
            v = max(v, float(np.exp(-(t - t0) / 0.45)))
    return v


# ------------------------------------------------------------------ camera
FRONT, PERSP, SIDE = (0.0, -90.0), (24.0, -58.0), (0.0, 0.0)
SIDE_SCENES = [k for k in ORDER if "side" in SC[k]["c"]]
_first_peel = SC[PEELERS[0]]["c"]["peel"]
CAM = [(0.0, FRONT), (_first_peel - 1.6, FRONT), (_first_peel + 0.4, PERSP)]
for key in SIDE_SCENES:
    sd = SC[key]["c"]["side"]
    nxt = SC[next_scene(key)]["start"]
    CAM += [(sd, PERSP), (sd + 2.0, SIDE), (nxt - 1.9, SIDE), (nxt - 0.3, PERSP)]
_close = SC[BUILD_KEY]["c"]["close"]
CAM += [(_close, PERSP), (_close + 2.6, FRONT), (DURATION + 1, FRONT)]

# half-wave symmetry interlude: face the wave, tilt for the flip, lanes for the
# harmonic test, face it again for the area sweep, then back to the lanes
TILT = (16.0, -74.0)
ABOVE = (36.0, -62.0)                               # lanes spread apart for the test
if "sym" in SC:
    _y = SC["sym"]["c"]
    CAM += [(_y["flat"], PERSP), (_y["flat"] + 1.6, FRONT),
            (_y["flip"], FRONT), (_y["flip"] + 0.8, TILT),
            (_y["match"] + 0.4, TILT), (_y["match"] + 1.6, FRONT),
            (_y["test"], FRONT), (_y["test"] + 1.6, ABOVE),
            (_y["area"], ABOVE), (_y["area"] + 1.6, FRONT),
            (_y["back"], FRONT), (_y["back"] + 1.8, PERSP)]
CAM.sort(key=lambda kv: kv[0])

# the wave drifts slowly to the left; it eases to a stop during the symmetry
# interlude so the shift / flip / sweep read cleanly, then drifts on again
_tg = np.linspace(0, DURATION + 2, int((DURATION + 2) * 100) + 1)
_rate = np.ones_like(_tg)
if "sym" in SC:
    # the drift nearly stops for the interlude; its slow residual rate r0 is solved
    # so the wave's phase at the next scene equals the original cut's (seamless joins)
    _nx = SC[next_scene("sym")]["start"]
    _hold = np.clip((_tg - SC["sym"]["start"]) / 1.0, 0, 1) * \
        (1 - np.clip((_tg - (_nx - 1.7)) / 1.5, 0, 1))
    _target = _nx
    try:
        _v2 = json.load(open("timeline_v2.json"))
        _target = [x for x in _v2["scenes"] if x["key"] == next_scene("sym")][0]["start"]
    except Exception:
        pass

    def _phase_at(r0):
        r = 1 - _hold * (1 - r0)
        p_ = np.concatenate([[0], np.cumsum(r[1:] * np.diff(_tg))])
        return np.interp(_nx, _tg, p_), r
    _a, _ = _phase_at(0.0)
    _b, _ = _phase_at(1.0)
    _r0 = (_target - _a) / (_b - _a)
    _, _rate = _phase_at(_r0)
    SYM_SHIFT = _nx - _target                     # later scenes = original cut + this
_ph = np.concatenate([[0], np.cumsum(_rate[1:] * np.diff(_tg))])


def phase(t):
    return float(np.interp(t, _tg, _ph))


sq = SC["square"]


def camera(t):
    for (t0, a), (t1, b) in zip(CAM, CAM[1:]):
        if t0 <= t <= t1:
            s_ = ramp(t, t0, max(t1 - t0, 1e-3))
            return a[0] + (b[0] - a[0]) * s_, a[1] + (b[1] - a[1]) * s_
    return CAM[-1][1]


# ------------------------------------------------------------------ figure
fig = plt.figure(figsize=(W, H), dpi=DPI, facecolor=SURFACE)
_S, _CX, _CY = 1.6, 0.6, 0.48
ax = fig.add_axes([_CX - _S * H / W / 2, _CY - _S / 2, _S * H / W, _S],
                  projection="3d", facecolor=SURFACE)
ax.set_axis_off()
ax.set_proj_type("persp", focal_length=1.1)
ax.set_xlim(0, X_LEN)
ax.set_ylim(-0.6, K + 0.6)
ax.set_zlim(-1.3, 1.3)
ZOOM_FLAT, ZOOM_PERSP = 0.8, 0.69

Z_FLOOR = -1.3
lane_floor = []
for yy in range(0, K + 1):
    ln, = ax.plot([0, X_LEN], [yy, yy], [Z_FLOOR] * 2, color=GRID, lw=0.9)
    lane_floor.append(ln)
for xx in np.linspace(0, X_LEN, 9):
    ax.plot([xx, xx], [-0.6, K + 0.6], [Z_FLOOR] * 2, color=GRID, lw=0.9)
AX_C = "#5a5955"
ax.plot([0, X_LEN + 0.2], [0, 0], [0, 0], color=AX_C, lw=1.2)
ax.plot([0, 0], [0, K + 0.6], [0, 0], color=AX_C, lw=1.2)
ax.plot([0, 0], [0, 0], [-1.2, 1.2], color=AX_C, lw=1.2)
lbl_time = ax.text(X_LEN + 0.3, 0, -0.15, "time", color=MUTED, fontsize=17)
lbl_freq = ax.text(0, K + 1.0, -0.15, "harmonic", color=MUTED, fontsize=17)
ax.text(0, 0, 1.38, "amplitude", color=MUTED, fontsize=17)
lane_lbls = [ax.text(X_LEN + 0.35, k, -0.35, f"{k}X", color=MUTED, fontsize=15,
                     alpha=0) for k in ks]


def glow_line(color, lw=2.8, halo=3.6):
    h, = ax.plot([], [], [], color=color, lw=lw * halo, alpha=0.1,
                 solid_capstyle="round")
    c, = ax.plot([], [], [], color=color, lw=lw, solid_capstyle="round")
    return h, c


def set_glow(pair, x, y, z, alpha, color=None):
    for ln, a in ((pair[0], 0.11 * alpha), (pair[1], alpha)):
        ln.set_data_3d(x, y, z)
        ln.set_alpha(max(a, 0.0))
        if color:
            ln.set_color(color)


front_line = glow_line(INK, 3.4)
comp_lines = [glow_line(BLUE if k == 1 else ORANGE, 2.4) for k in ks]
ghost_lines = [glow_line(BLUE if k == 1 else ORANGE, 1.6) for k in ks]
BAR_X = X_LEN + 0.05
bar_lines = [glow_line(BLUE if k == 1 else ORANGE, 11, 1.7) for k in ks]
ping_rings = [ax.plot([], [], [], "o", mfc="none", mew=2.5, ms=10,
                      color=BLUE if k == 1 else ORANGE, alpha=0)[0] for k in ks]
dc_line, = ax.plot([], [], [], color=MUTED, lw=2.5, ls=(0, (6, 4)), alpha=0)
dc_lbl = ax.text(X_LEN * 0.5, 0, 0.55, "constant (DC) offset", color=INK2,
                 fontsize=18, alpha=0, ha="center")

# 2D overlay text
kicker_t = fig.text(0.03, 0.958, "", fontsize=17, color=ORANGE, fontweight="bold")
title_t = fig.text(0.03, 0.91, "", fontsize=34, color=INK, fontweight="bold",
                   va="center")
result_t = fig.text(0.97, 0.91, "", fontsize=26, color=INK, ha="right",
                    va="center", fontweight="bold")
hook_t = fig.text(0.5, 0.905, "Why do we see harmonics?", fontsize=52,
                  color=INK, ha="center", va="center", fontweight="bold")
sub_t = fig.text(0.55 if SILENT else 0.5, 0.072 if SILENT else 0.075, "",
                 fontsize=30 if SILENT else 27, color=INK, ha="center",
                 va="center", linespacing=1.35, zorder=30,
                 fontweight="bold" if SILENT else "normal",
                 bbox=dict(boxstyle="round,pad=0.55", facecolor="#000000",
                           edgecolor="none", alpha=0.62))
veil = fig.add_axes([0, 0, 1, 1], zorder=20)
veil.set_axis_off()
veil_r = plt.Rectangle((0, 0), 1, 1, transform=veil.transAxes,
                       facecolor=SURFACE, alpha=1)
veil.add_patch(veil_r)

RESULTS = [  # (scene, global time, text)
    ("intro", SC["intro"]["c"]["side"] + 2.0, "one sine  →  one peak"),
    ("messy", SC["messy"]["c"]["side"] + 2.0, "one signal  →  many peaks"),
    ("square", SC["square"]["c"]["side"] + 2.0, "odd harmonics only  ·  ∝ 1/n"),
    ("sawtooth", SC["sawtooth"]["c"]["peel"] + 2.2, "every harmonic  ·  ∝ 1/n"),
    ("triangle", SC["triangle"]["c"]["peel"] + 2.0, "odd only  ·  ∝ 1/n²"),
    ("cut", SC["cut"]["c"]["peel"] + 1.5, "symmetry broken  →  even harmonics"),
    ("payoff", SC["payoff"]["c"]["side"] + 2.0, "every peak  =  one lane"),
]
ALL_LINES = [l for s in TL["scenes"] for l in s["lines"]]

# ---- maths row: (global start time, mathtext) - each replaces the previous
eq_t = fig.text(0.03, 0.83, "", fontsize=31, color=INK, ha="left", va="center")
_in, _me, _wh, _sq = SC["intro"], SC["messy"], SC["why"], SC["square"]
EQS = [
    (_in["c"]["intro"] + 0.2, r"$f(t)=\sin(\omega_0 t)$"),
    (_in["c"]["side"] + 2.0, r"$|c_1|=1,\qquad c_n=0\quad (n\geq 2)$"),
    (_me["start"] + 0.3, r"$f(t)=\ ?$"),
    (_me["c"]["side"] + 2.0, r"$|c_n|\neq 0\quad \mathrm{for\ many}\ n$"),
    (_wh["start"] + 0.3, r"$f(t+T)=f(t)$"),
    (_wh["c"]["lanes"] + 0.2,
     r"$f(t)=a_0+\sum_{n=1}^{\infty}\left[a_n\cos(n\omega_0 t)+b_n\sin(n\omega_0 t)\right]$"),
    (_sq["start"] + 0.2,
     r"$\mathrm{sgn}(\sin\omega_0 t)=\dfrac{4}{\pi}\sum_{n\ \mathrm{odd}}\dfrac{\sin(n\omega_0 t)}{n}$"),
    (_sq["c"]["empty"] + 0.2, r"$a_n=b_n=0\quad\mathrm{for\ even}\ n$"),
    (_sq["c"]["side"] + 2.0, r"$|c_n|=\sqrt{a_n^2+b_n^2}=\dfrac{4}{\pi n},\quad n=1,3,5,\dots$"),
    (SC["sawtooth"]["start"] + 0.2,
     r"$f(t)=\dfrac{2}{\pi}\sum_{n=1}^{\infty}(-1)^{n+1}\,\dfrac{\sin(n\omega_0 t)}{n}$"),
    (SC["triangle"]["start"] + 0.2,
     r"$f(t)=\dfrac{8}{\pi^2}\sum_{n\ \mathrm{odd}}(-1)^{\dfrac{n-1}{2}}\,\dfrac{\sin(n\omega_0 t)}{n^2}$"),
    (SC["cut"]["start"] + 0.2,
     r"$\max(\sin\omega_0 t,\,0)=\dfrac{1}{\pi}+\dfrac{1}{2}\sin\omega_0 t-\dfrac{2}{\pi}\sum_{n\ \mathrm{even}}\dfrac{\cos(n\omega_0 t)}{n^2-1}$"),
    (SC["cut"]["c"]["dc"] + 0.1, r"$\mathrm{leftover}=a_0=\dfrac{1}{\pi}\approx 0.32\quad\mathrm{(DC\ offset)}$"),
    (SC["payoff"]["start"] + 0.2,
     r"$f(t)=a_0+\sum_{n=1}^{\infty}c_n\cos(n\omega_0 t+\varphi_n)$"),
    (SC[BUILD_KEY]["start"] + 0.2,
     r"$\sum_{n=1}^{10}\left[a_n\cos(n\omega_0 t)+b_n\sin(n\omega_0 t)\right]\ \longrightarrow\ f(t)$"),
]
if "sym" in SC:
    _y = SC["sym"]["c"]
    EQS += [
        (_y["match"] + 0.3, r"$f\left(t+\dfrac{T}{2}\right)=-f(t)$"),
        (_y["test"] + 0.3, r"$\sin\left(n\omega_0\left(t+\dfrac{T}{2}\right)\right)=\sin(n\omega_0 t+n\pi)=(-1)^n\sin(n\omega_0 t)$"),
        (_y["cancel"] + 0.3, r"$b_2=-\,b_2\quad\Rightarrow\quad b_2=0$"),
        (_y["area"] + 0.3, r"$b_n=\dfrac{2}{T}\int_0^{T} f(t)\,\sin(n\omega_0 t)\,dt$"),
        (_y["sweep3"] + 4.6, r"$b_3=\dfrac{4}{3\pi}\approx 0.42$"),
    ]
    EQS.sort(key=lambda e_: e_[0])
EQ_END = SC[BUILD_KEY]["c"]["close"] - 0.3


def set_eq(t):
    cur = None
    for t0, tex in EQS:
        if t >= t0:
            cur = (t0, tex)
    if cur is None or t > EQ_END + 0.4:
        eq_t.set_text("")
        return
    eq_t.set_text(cur[1])
    eq_t.set_alpha(ramp(t, cur[0], 0.35) * (1 - ramp(t, EQ_END, 0.4)))


def subtitle(t):
    for l in ALL_LINES:
        if l["start"] - 0.05 <= t <= l["end"] + (0.0 if SILENT else 0.25):
            return "\n".join(textwrap.wrap(l["text"], 56 if SILENT else 66))
    return ""


def draw(t):
    elev, azim = camera(t)
    ax.view_init(elev=elev, azim=azim)
    p = elev / PERSP[0]
    ax.set_box_aspect((X_LEN, 5.2, 3.0), zoom=ZOOM_FLAT + (ZOOM_PERSP - ZOOM_FLAT) * p)
    side = 1 - abs(azim) / 58.0 if azim > -58 else 0.0
    side = float(np.clip(side, 0, 1))

    tt = tau + 0.15 * t
    prev, cur, m = active(t)

    # ---- components: the current example (and the previous one sliding home)
    keys = [cur] if prev == cur else [prev, cur]
    drawn = {k: (0.0, None) for k in ks}
    front = None
    Ep, Ec = EXOF(prev), EXOF(cur)
    base = Ec.full(tt) if prev == cur else (1 - m) * Ep.full(tt) + m * Ec.full(tt)
    front = base.copy()
    for key in keys:
        if key not in PEEL:
            continue
        C = EXOF(key).comps(tt)
        for k in ks:
            mv = moved(key, k, t)
            if mv <= 0:
                continue
            # only the morph target's leftover is reduced (prev comps are going home)
            if key == cur:
                front -= mv * C[k - 1]
            elif m < 0.02:
                front -= mv * C[k - 1]
            if mv > drawn[k][0]:
                drawn[k] = (mv, C[k - 1])
    for k, ln, bl in zip(ks, comp_lines, bar_lines):
        mv, c = drawn[k]
        a = min(1.0, mv * 3) * (1 - 0.85 * side)
        if c is not None:
            set_glow(ln, X, np.full(N_PTS, k * mv), c, a)
        else:
            set_glow(ln, [], [], [], 0)
        # bar height: amplitude of whichever example owns the lane
        amp = 0.0
        for key in keys:
            if key in PEEL:
                amp = max(amp, EXOF(key).amp[k - 1] * moved(key, k, t))
        set_glow(bl, [BAR_X, BAR_X], [k, k], [0, amp], 1.0 if amp > 0.005 else 0)
        fk = flash(k, t) if SILENT else 0.0
        rg = ping_rings[k - 1]
        if fk > 0.02:
            rg.set_data_3d([BAR_X], [k], [max(amp, 0.0)])
            rg.set_markersize(10 + 34 * (1 - fk))
            rg.set_alpha(fk)
        else:
            rg.set_alpha(0)

    col = BLUE if SC[cur]["ex"] == "sine" and (SC[prev]["ex"] == "sine" or m > 0.5) else INK
    set_glow(front_line, X, np.zeros(N_PTS), front, 1 - 0.85 * side, col)

    # ---- setup: ghost sines show which waves fit (1X..10X)
    s = SC["why"]
    ga = ramp(t, s["c"]["lanes"] + 1.2, 0.8) * (1 - ramp(t, s["L"][2][1] + 0.3, 0.8))
    for k, gl in zip(ks, ghost_lines):
        a = ga * ramp(t, s["c"]["lanes"] + 1.2 + 0.12 * k, 0.4)
        set_glow(gl, X, np.full(N_PTS, k), 0.4 * np.sin(w0 * k * tt), 0.45 * a)

    # ---- lane labels and the empty-lane highlight in the square example
    lab_a = ramp(t, _first_peel - 0.6, 0.8) * (1 - ramp(t, SC[BUILD_KEY]["c"]["close"], 1.5))
    empty = ramp(t, sq["c"]["empty"], 0.4) * (1 - ramp(t, sq["c"]["side"] - 0.6, 0.6))
    pulse = 0.5 + 0.5 * np.sin(2 * np.pi * 1.2 * (t - sq["c"]["empty"]))
    for k, lab, fl in zip(ks, lane_lbls, lane_floor[1:]):
        is_empty = (k % 2 == 0) and empty > 0
        fl_k = flash(k, t)
        lab.set_alpha(min(1.0, 0.9 * lab_a + fl_k))
        lab.set_color((BLUE if k == 1 else ORANGE) if fl_k > 0.15 else (ORANGE if is_empty else MUTED))
        lab.set_fontweight("bold" if (is_empty or fl_k > 0.15) else "normal")
        lab.set_fontsize(15 + 9 * fl_k)
        if fl_k > 0.05 and not is_empty:
            fl.set_color(BLUE if k == 1 else ORANGE)
            fl.set_alpha(0.25 + 0.65 * fl_k)
            fl.set_linewidth(0.9 + 2.5 * fl_k)
        elif is_empty:
            fl.set_color(ORANGE)
            fl.set_alpha(empty * (0.35 + 0.5 * pulse))
            fl.set_linewidth(2.5)
        else:
            fl.set_color(GRID)
            fl.set_alpha(1)
            fl.set_linewidth(0.9)
    lbl_freq.set_alpha(lab_a)
    lbl_time.set_alpha(1 - side)

    # ---- DC offset left behind by the cut sine
    c = SC["cut"]
    da = ramp(t, c["c"]["dc"], 0.5) * (1 - ramp(t, SC[next_scene("cut")]["start"] - 1.2, 0.6))
    dc_line.set_data_3d([0, X_LEN], [0, 0], [EX["cut"].dc] * 2)
    dc_line.set_alpha(0.9 * da)
    dc_lbl.set_alpha(0)              # explained in the maths row instead

    # ---- 2D text
    first_end = SC["intro"]["L"][0][1]
    hook_t.set_alpha(1 - ramp(t, first_end - 0.4, 0.5))
    key_title = cur if t >= SC[cur]["start"] - 0.2 else prev
    if t >= SC[BUILD_KEY]["start"] - 0.2:
        key_title = BUILD_KEY
    S = SC[key_title]
    ta = ramp(t, max(S["start"], first_end if key_title == "intro" else 0) - 0.2, 0.5)
    kicker_t.set_text(S["kicker"])
    title_t.set_text(S["title"])
    kicker_t.set_alpha(ta)
    title_t.set_alpha(ta)
    result_t.set_text("")
    for key, t0, txt in RESULTS:
        if t0 <= t < SC[next_scene(key)]["start"] - 0.3:
            result_t.set_text(txt)
            result_t.set_color(ORANGE)
            result_t.set_alpha(ramp(t, t0, 0.5))
    set_eq(t)
    sub_t.set_text(subtitle(t))
    sub_t.set_visible(bool(sub_t.get_text()))
    veil_r.set_alpha(max(1 - ramp(t, 0, 0.6), ramp(t, DURATION - 0.8, 0.7)))
    if MASC is not None:
        MASC.draw(t)


MASC = None
if SILENT and os.environ.get("MASCOT", "1") == "1":
    import mascot2 as _mascot
    MASC = _mascot.Mascot(sys.modules[__name__])


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "examples3d.mp4"
    n_total = int(np.ceil(DURATION * FPS))
    f0 = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    f1 = int(sys.argv[3]) if len(sys.argv) > 3 else n_total
    writer = FFMpegWriter(fps=FPS, codec="libx264", bitrate=-1,
                          extra_args=["-vf", "scale=1920:1080:flags=lanczos",
                                      "-pix_fmt", "yuv420p", "-profile:v", "high",
                                      "-preset", "medium", "-crf", "15"])
    with writer.saving(fig, out, dpi=DPI * SS):
        for i in range(f0, f1):
            draw(i / FPS)
            writer.grab_frame(facecolor=SURFACE)
            if (i - f0) % 600 == 0:
                print(f"{out}: frame {i - f0}/{f1 - f0}", flush=True)
    print("done:", out)
