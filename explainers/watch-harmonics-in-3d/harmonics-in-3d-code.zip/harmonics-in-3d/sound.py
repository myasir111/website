"""
Sound design v2 for the sound-only 3D video: no continuous signal tone.

  music bed : soft generated loop in D major (D - Bm - G - A), electric-piano
              arpeggios + warm bass, 92 bpm, quiet, ducked at the big reveal
  plucks    : kalimba / bell tone at each harmonic's own pitch (n x D3),
              panned to its lane (1X left ... 10X right)
  accents   : wood-block taps on empty lanes, "bloop" glides on morphs,
              soft whooshes, riser + low hit + chime on the spectrum reveal,
              gentle tocks when a caption changes, bell chord at the end

Usage:  TIMELINE=timeline_silent.json python3 sfx_v2.py -> sound_v2.wav
"""
import os
os.environ.setdefault("TIMELINE", "timeline_v2.json")
import numpy as np
import soundfile as sf
import examples3d_v2 as e
FX_GAIN = float(os.environ.get("FX_GAIN", 0.05))

SR = 48000
F0 = 146.83                      # D3: pitch of 1X
DUR = e.DURATION
N = int((DUR + 2.0) * SR)
L = np.zeros(N)
R = np.zeros(N)
rng = np.random.default_rng(5)
ks = np.arange(1, 11)
LANE_PAN = {k: -0.75 + 1.5 * (k - 1) / 9 for k in ks}
SC = e.SC


def pan_gains(p):
    a = (p + 1) * np.pi / 4
    return np.cos(a), np.sin(a)


def place(t, x, g=1.0, pan=0.0, bus=None):
    i = int(t * SR)
    if i < 0 or i >= N:
        return
    j = min(i + len(x), N)
    gl, gr = pan_gains(pan)
    if bus is None:
        L[i:j] += g * gl * x[: j - i]
        R[i:j] += g * gr * x[: j - i]
    else:
        bus[0][i:j] += g * gl * x[: j - i]
        bus[1][i:j] += g * gr * x[: j - i]


def env(n, a=0.005, d=0.8):
    t = np.arange(n) / SR
    return np.minimum(t / a, 1) * np.exp(-t / d)


def midi(m):
    return 440.0 * 2 ** ((m - 69) / 12)


# ---------------------------------------------------------------- instruments
def kalimba(f, dur=1.6, bright=1.0):
    t = np.arange(int(dur * SR)) / SR
    x = (np.sin(2 * np.pi * f * t) * np.exp(-t / 0.75)
         + 0.35 * bright * np.sin(2 * np.pi * 3.01 * f * t) * np.exp(-t / 0.18)
         + 0.12 * bright * np.sin(2 * np.pi * 5.43 * f * t) * np.exp(-t / 0.05))
    click = rng.standard_normal(int(0.004 * SR)) * np.linspace(1, 0, int(0.004 * SR))
    x[: len(click)] += 0.15 * click
    return x * np.minimum(t / 0.002, 1)


def swell(f, dur=1.1, attack=0.09):
    """Soft pitched swell: pure tone, gentle fade-in, no click, plus a breath of air."""
    t = np.arange(int(dur * SR)) / SR
    env_ = np.minimum(t / attack, 1) ** 2 * np.exp(-np.maximum(t - attack, 0) / 0.32)
    tone = np.sin(2 * np.pi * f * t)
    air = rng.standard_normal(len(t))
    # light band-limiting of the air noise around the tone (cheap: smooth + mix)
    air = np.convolve(air, np.ones(24) / 24, "same") * 0.25
    return (tone + air) * env_ * np.sin(np.pi * np.minimum(t / dur, 1)) ** 0.3


def pluck_old(k):
    return kalimba(F0 * k, 1.6, bright=1 / (1 + 0.12 * k)) / (1 + 0.07 * k)


def air_swell(dur=1.1, attack=0.09):
    """The soft breath layer of a swell, without its pitched tone."""
    t = np.arange(int(dur * SR)) / SR
    env_ = np.minimum(t / attack, 1) ** 2 * np.exp(-np.maximum(t - attack, 0) / 0.32)
    air = np.convolve(rng.standard_normal(len(t)), np.ones(24) / 24, "same") * 0.25
    return air * env_ * np.sin(np.pi * np.minimum(t / dur, 1)) ** 0.3


def pluck(k):
    # every harmonic still sounds at its own pitch (k x D3), but as a soft swell;
    # higher ones a little quieter so fast runs stay gentle
    return swell(F0 * k) / (1 + 0.12 * k)


def epiano(f, dur=1.4):
    t = np.arange(int(dur * SR)) / SR
    trem = 1 + 0.08 * np.sin(2 * np.pi * 5.0 * t)
    x = (np.sin(2 * np.pi * f * t) + 0.22 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t / 0.25)
         + 0.06 * np.sin(2 * np.pi * 3 * f * t) * np.exp(-t / 0.12))
    return x * env(len(t), 0.008, 0.9) * trem


def bass(f, dur):
    t = np.arange(int(dur * SR)) / SR
    x = np.sin(2 * np.pi * f * t) + 0.18 * np.sin(2 * np.pi * 2 * f * t)
    e_ = np.minimum(t / 0.04, 1) * np.exp(-t / (dur * 0.9)) * np.clip((dur - t) / 0.15, 0, 1)
    return x * e_


def woodblock():
    t = np.arange(int(0.25 * SR)) / SR
    x = (np.sin(2 * np.pi * 820 * t) * np.exp(-t / 0.035)
         + 0.5 * np.sin(2 * np.pi * 1390 * t) * np.exp(-t / 0.02))
    nz = rng.standard_normal(len(t)) * np.exp(-t / 0.004) * 0.3
    return 0.8 * (x + nz)


def bloop(f1=240, f2=560, dur=0.22):
    t = np.arange(int(dur * SR)) / SR
    f = f1 * (f2 / f1) ** (t / dur)
    return 0.6 * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t / dur) ** 1.5


def filtered_noise(dur, f_a, f_b, shape):
    n = int(dur * SR)
    noise = rng.standard_normal(n)
    u = np.linspace(0, 1, n)
    fc = f_a * (f_b / f_a) ** u if shape == "rise" else f_a * (f_b / f_a) ** np.sin(np.pi * u)
    a = np.exp(-2 * np.pi * fc / SR)
    y = np.zeros(n)
    acc = 0.0
    for i in range(n):
        acc = a[i] * acc + (1 - a[i]) * noise[i]
        y[i] = acc
    y -= np.convolve(y, np.ones(96) / 96, "same")
    amp = u ** 2.4 if shape == "rise" else np.sin(np.pi * u) ** 2
    return 2.2 * y * amp


def whoosh(dur=0.9):
    return filtered_noise(dur, 180, 1600, "bell")


def riser(dur=1.8):
    return filtered_noise(dur, 250, 4500, "rise")


def low_hit():
    t = np.arange(int(1.3 * SR)) / SR
    f = 85 * np.exp(-t / 0.18) + 40
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.004, 0.4)


def tock():
    t = np.arange(int(0.06 * SR)) / SR
    return 0.5 * np.sin(2 * np.pi * 1480 * t) * env(len(t), 0.001, 0.012)


def bell_chord(ms, spread=0.07, dur=2.6):
    out = np.zeros(int((dur + spread * len(ms)) * SR))
    for i, m in enumerate(ms):
        x = kalimba(midi(m), dur, 0.8)
        d = int(i * spread * SR)
        out[d: d + len(x)] += x * (0.85 ** i)
    return 0.6 * out


# ---------------------------------------------------------------- 1. music bed
bed = (np.zeros(N), np.zeros(N))
BPM = 92
beat = 60 / BPM
eighth = beat / 2
bar = 4 * beat
CHORDS = [  # (bass midi, arp notes)
    (38, [62, 66, 69, 74]),          # D
    (35, [59, 62, 66, 71]),          # Bm
    (31, [55, 59, 62, 67]),          # G
    (33, [57, 61, 64, 69]),          # A
]
PATTERN = [0, 1, 2, 3, 2, 1, 2, 3]
t, ci = 0.4, 0
while t < DUR + 1:
    b, arp = CHORDS[ci % 4]
    place(t, bass(midi(b), 2 * bar), 0.55, 0.0, bed)
    for barno in range(2):
        for j, idx in enumerate(PATTERN):
            tn = t + barno * bar + j * eighth + rng.normal(0, 0.004)
            vel = (0.9 if j % 2 == 0 else 0.7) * rng.uniform(0.9, 1.05)
            place(tn, epiano(midi(arp[idx]), 1.3), 0.32 * vel,
                  0.25 if j % 2 else -0.25, bed)
    t += 2 * bar
    ci += 1

ts = np.arange(N) / SR
duck = np.ones(N)
for _k in e.SIDE_SCENES:                                      # dip under each reveal
    _sd = SC[_k]["c"]["side"]
    duck *= 1 - 0.55 * np.clip(np.minimum((ts - (_sd - 0.2)) / 0.5,
                                           ((_sd + 4.0) - ts) / 1.0), 0, 1)
fade = np.minimum(1, ts / 2.5) * np.clip((DUR + 0.6 - ts) / 3.0, 0, 1)
for ch in bed:
    ch *= duck * fade

# ---------------------------------------------------------------- 2. accents
for s in e.TL["scenes"]:
    for l in s["lines"]:
        pass                                                 # (no caption tocks)

place(e._first_peel - 1.6, whoosh(2.2), 0.12)                 # camera into 3D

lanes = SC["why"]["c"]["lanes"]
for k in ks:                                                 # whole multiples that fit
    place(lanes + 1.2 + 0.12 * k, air_swell(), 0.35 * 2, LANE_PAN[k])   # tone removed, air kept

for key in e.ORDER[1:]:                                      # every new shape forms
    s_ = SC[key]
    pass
    place(s_["start"] + e.MORPH_DELAY + 0.05, whoosh(1.3), 0.07)
for key in e.PEELERS:
    if key != e.LAST:                                        # sines slide home
        place(SC[e.next_scene(key)]["start"] - e.HOME_LEAD, whoosh(1.4), 0.08)
    for k, t0 in e.PEEL[key].items():
        place(t0 + 0.15, air_swell(), 0.6 * 2, LANE_PAN[k])   # tone removed, air kept

REVEAL = {  # chord (midi) and weight of each side-view reveal
    "intro": ([74], 0.45),
    "messy": ([74, 78, 81, 86], 0.6),
    "square": ([74, 78, 81], 0.6),
    "payoff": ([62, 66, 69, 74, 78], 0.7),
}
for key in e.SIDE_SCENES:
    sd = SC[key]["c"]["side"]
    chord, g = REVEAL.get(key, ([74, 78, 81], 0.6))
    place(sd + 0.25, riser(1.8), 0.12 * g / 0.6)
    place(sd + 2.0, low_hit(), 0.3 * g / 0.6)
    place(sd + 2.0, bell_chord(chord), 0.4 * g / 0.6)
    place(SC[e.next_scene(key)]["start"] - 1.9, whoosh(2.0), 0.08)   # camera turns back

sq = SC["square"]
for i, k in enumerate((2, 4, 6, 8, 10)):                     # empty lanes
    place(sq["c"]["empty"] + 0.2 + 0.17 * i, woodblock(), 0.22, LANE_PAN[k])

place(SC["cut"]["c"]["dc"] + 0.1, bloop(330, 160, 0.3), 0.18)   # DC: settles down

for k, t0 in e.BUILD.items():                                # sines return
    place(t0 + 0.4, air_swell(), 0.55 * 2, LANE_PAN[k])   # tone removed, air kept
place(max(e.BUILD.values()) + 1.1, bell_chord([62, 66, 69, 74]), 0.4)
close = SC["build"]["c"]["close"]
place(close, whoosh(2.6), 0.07)
place(close + 2.6, bell_chord([50, 57, 62, 66, 69, 74], 0.09, 3.5), 0.5)

# ---------------------------------------------------------------- 2b. symmetry interlude
def soft_chord(ms, dur=1.8):
    out = np.zeros(int((dur + 0.4) * SR))
    for i, m in enumerate(ms):
        x = swell(midi(m), dur, 0.15)
        d = int(i * 0.05 * SR)
        out[d: d + len(x)] += x * 0.85 ** i
    return out / len(ms) ** 0.5


if "sym" in SC:
    y = SC["sym"]["c"]
    place(y["flat"] + 0.1, whoosh(1.6), 0.06)                    # camera turns to face the wave
    place(y["shift"] + 0.3, whoosh(1.5), 0.07)                   # copy slides half a turn
    place(y["flip"] + 0.4, whoosh(1.6), 0.08)                    # copy flips over
    place(y["match"] + 0.05, soft_chord([62, 66, 69]), 0.35)     # lands on itself
    place(y["test"] + 0.1, whoosh(1.6), 0.06)                    # camera to the lanes
    place(y["tflip"] + 0.2, whoosh(1.3), 0.06)
    place(y["tflip"] + 1.7, whoosh(1.3), 0.07)
    place(y["verdict"] + 0.05, soft_chord([62, 69]), 0.25)
    place(y["cancel"] + 0.4, whoosh(1.6), 0.06)                  # 2X and its copy merge
    place(y["cancel"] + 2.0, low_hit(), 0.18)                    # 2X settles to zero
    place(y["area"] + 0.1, whoosh(1.6), 0.06)                    # camera faces the wave again
    place(y["zero2"] + 0.05, low_hit(), 0.18)                    # areas cancel: zero
    place(y["sweep3"] + 4.65, soft_chord([62, 66, 69, 74]), 0.35)  # areas add up
    place(y["back"] + 0.2, whoosh(1.8), 0.07)                    # back to the lanes

# ---------------------------------------------------------------- 3. mascot
def glide(f1, f2, dur, vib=0.0, vib_hz=7.0, shape=1.5):
    t = np.arange(int(dur * SR)) / SR
    f = f1 * (f2 / f1) ** (t / dur) * (1 + vib * np.sin(2 * np.pi * vib_hz * t))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) + 0.2 * np.sin(4 * np.pi * np.cumsum(f) / SR)
    return 0.5 * x * np.sin(np.pi * t / dur) ** shape


def pop():
    return glide(500, 1300, 0.09, shape=1.0) * 1.2


def blip():
    t = np.arange(int(0.07 * SR)) / SR
    return 0.35 * np.sin(2 * np.pi * 1320 * t) * env(len(t), 0.002, 0.025)


def boing(dur=0.7):
    t = np.arange(int(dur * SR)) / SR
    f = 260 * (1 + 0.35 * np.exp(-t / 0.18) * np.sin(2 * np.pi * 11 * t)) + 120 * np.exp(-t / 0.1)
    return 0.6 * np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.003, 0.3)


def clank():
    t = np.arange(int(0.8 * SR)) / SR
    x = sum(a * np.sin(2 * np.pi * f * t) * np.exp(-t / d)
            for f, a, d in ((523, 1.0, 0.25), (1290, 0.6, 0.12), (2210, 0.4, 0.07), (3170, 0.3, 0.05)))
    return 0.55 * x + 0.8 * low_hit()[: len(t)]


def sparkles(n=12, span=1.2):
    out = np.zeros(int((span + 0.8) * SR))
    for i in range(n):
        x = kalimba(rng.uniform(1700, 3600), 0.6, 0.5) * rng.uniform(0.3, 0.7)
        d = int(rng.uniform(0, span) * SR)
        out[d: d + len(x)] += x[: len(out) - d]
    return 0.5 * out


M = e.MASC
for kind, t0, d in M.events:
    if kind == "appear":
        place(t0 + 0.05, pop(), 0.3, -0.6)
    elif kind == "excited":
        pass
    elif kind == "surprise":
        pass
    elif kind == "happy":
        pass
    elif kind == "confetti":
        place(t0 + 0.1, sparkles(10, 1.3), 0.3, -0.3)
    elif kind == "slam":
        place(t0 + 0.12, clank(), 0.35, -0.5)
        pass
    elif kind == "dizzy":
        pass
        pass
    elif kind == "wink":
        for i, m_ in enumerate((86, 90, 93, 98)):                          # sparkle up
            place(t0 + 0.05 + 0.06 * i, kalimba(midi(m_), 0.8, 0.6), 0.2, -0.5)
for t0, d, txt in M.bubbles:
    pass                                                                   # (no bubble blips)

# ---------------------------------------------------------------- mix
fx = np.stack([L, R], 1)
bedm = np.stack(bed, 1)
fx_peak = np.max(np.abs(fx))
fx *= FX_GAIN                                 # effects relative to the music
BED_RMS = 0.02
bed_rms = np.sqrt(np.mean(bedm[int(3 * SR): int((DUR - 3) * SR)] ** 2))
# music bed sits ~29 dB below the loudest effect
bedm *= BED_RMS / bed_rms                     # music at a fixed level
mix = fx + bedm
mix /= np.max(np.abs(mix))
mix *= 0.9
sf.write("sound_soft_np.wav", mix, SR)
if os.environ.get("STEMS"):
    _w = int(0.05 * SR)
    def _rms_db(x):
        m_ = x.mean(1); n_ = len(m_) // _w
        return 20 * np.log10(np.sqrt((m_[:n_ * _w].reshape(n_, _w) ** 2).mean(1)) + 1e-9)
    rf, rb = _rms_db(fx), _rms_db(bedm)
    act = rf > rf.max() - 30
    print(f"music median {np.median(rb[60:-60]):.1f} dB | effects: median-when-sounding "
          f"{np.median(rf[act]):.1f} dB, loudest {rf.max():.1f} dB  -> loudest effect is "
          f"{rf.max() - np.median(rb[60:-60]):+.1f} dB vs music")
print("written", round(N / SR, 1), "s; bed/fx-peak = -29 dB")
