# Harmonics in 3D: the code behind the video

Python + [Manim Community](https://www.manim.community/) (v0.22). Everything is driven by one timeline,
so the animation, the captions, the mascot and the sound all stay in sync.

| File | What it does |
|---|---|
| `captions_v3.py` | The story: scenes, captions and cue times. Writes `timeline_v3.json`. |
| `examples3d_v2.py` | The maths and choreography: the example signals, their Fourier coefficients, when each sine peels out, the camera path. |
| `manim_story.py` | Draws every frame with Manim: 3D lanes, spectrum bars, the half-wave symmetry interlude, the maths row, captions. |
| `mascot2.py` | The wave mascot: its body is one period of the current signal; expressions and speech bubbles. |
| `sound.py` | The soundtrack, generated in NumPy: a quiet music bed and soft effects on the timeline's cues. |

## Run it

You need Python 3.10+, `pip install manim numpy scipy matplotlib soundfile`, ffmpeg, and a LaTeX install (for the maths).

```bash
python captions_v3.py                                    # 1. build the timeline
export TIMELINE=timeline_v3.json
manim -qh manim_story.py Story -o story.mp4              # 2. render (1080p60; use -ql for a quick preview)
python sound.py                                          # 3. soundtrack -> sound_soft_np.wav
ffmpeg -i media/videos/manim_story/1080p60/story.mp4 -i sound_soft_np.wav \
       -map 0:v -map 1:a -c:v copy -c:a aac -shortest harmonics-in-3d.mp4   # 4. put them together
```

Rendering the full 3:46 at 1080p60 takes a while. To render a slice, set `T0` and `T1` (seconds),
for example `T0=79 T1=157 manim -qh manim_story.py Story -o part.mp4`, and render slices in parallel.

To change the story, edit the captions in `captions_v3.py`: cue tags like `[peel]` or `[flip]` set when things
happen, and `{+1.2}` adds a pause after a line.

Made by Muhammad Yasir · https://nodallab.dev
