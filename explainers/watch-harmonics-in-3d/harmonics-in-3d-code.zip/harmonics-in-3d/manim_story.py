"""
Manim version of the harmonics story (same timeline + sound as the
Matplotlib cut, so the audio track lines up unchanged).

All timing / maths / camera choreography is imported from examples3d_v2,
so both versions tell exactly the same story; Manim does the drawing:
  - 3D lanes, curves, spectrum bars in a ThreeDScene (vector, Cairo)
  - LaTeX maths row that WRITES itself on (Manim's Write animation)
  - opening curve draws itself in (Create), captions glide in
  - mascot, bubbles and confetti drawn as Manim vector shapes

Render a time slice (seconds):
  T0=0 T1=20 manim -qh --fps 60 manim_story.py Story -o part.mp4
"""
import os
os.environ.setdefault("TIMELINE", "timeline_v2.json")
import numpy as np
from manim import *                                       # noqa: F401,F403
from manim.utils.family import extract_mobject_family_members
import examples3d_v2 as E                                 # shared choreography

config.pixel_width, config.pixel_height = 1920, 1080
config.frame_rate = 60
if os.environ.get("PREVIEW"):
    config.pixel_width, config.pixel_height, config.frame_rate = 960, 540, 15
config.background_color = "#111110"

SURF, INKc, INK2c, MUTEDc = "#111110", "#f0efec", "#c3c2b7", "#898781"
GRIDc, AXc = "#2c2c2a", "#5a5955"
BLUEc, ORANGEc, GOODc = "#3987e5", "#d95926", "#0ca30c"
OKc, BADc = "#2bb24c", "#e0503a"
SANS = "DejaVu Sans"

T0 = float(os.environ.get("T0", 0))
T1 = float(os.environ.get("T1", E.DURATION))

K, XL = E.K, E.X_LEN
SX, SY, SZ = 1.0, 0.56, 1.1
N_PTS = 220
TAU = np.linspace(0, 2, N_PTS)
XS = TAU / 2 * XL


def P(x, y, z):
    """engine coordinates -> Manim world coordinates (scene centred on origin)."""
    return np.array([(x - XL / 2) * SX, (y - K / 2) * SY, z * SZ])


def PTS(x, y, z):
    x = np.broadcast_to(x, np.shape(z) if np.ndim(z) else np.shape(x))
    y = np.broadcast_to(y, np.shape(x))
    return np.stack([(x - XL / 2) * SX, (y - K / 2) * SY, np.asarray(z) * SZ], 1)


def curve(points, color, width, opacity=1.0):
    m = VMobject(stroke_color=color, stroke_width=width, stroke_opacity=opacity)
    m.set_points_as_corners(points)
    return m


def glow_curve(points, color, width=3.0, opacity=1.0):
    g = VGroup(curve(points, color, width * 3.6, 0.11 * opacity),
               curve(points, color, width, opacity))
    return g


_text_cache = {}


def T(s, size=30, color=INKc, weight=NORMAL, font=SANS):
    key = (s, size, color, weight, font)
    if key not in _text_cache:
        _text_cache[key] = Text(s, font=font, font_size=size, color=color, weight=weight)
    return _text_cache[key].copy()


_tex_cache = {}


def TEX(s, size=38):
    key = (s, size)
    if key not in _tex_cache:
        body = s.strip("$")
        _tex_cache[key] = MathTex(body, font_size=size, color=INKc)
    return _tex_cache[key].copy()


def ease(x):
    x = float(np.clip(x, 0, 1))
    return x * x * (3 - 2 * x)


def ramp(t, t0, d=0.6):
    return ease((t - t0) / d)


# map figure fractions (0..1) used by the Matplotlib layout to Manim frame coords
FW, FH = config.frame_width, config.frame_height


def FIG(fx, fy):
    return np.array([(fx - 0.5) * FW, (fy - 0.5) * FH, 0])


class Story(Scene):
    def construct(self):
        self.cam = self.renderer.camera
        self.clock = ValueTracker(T0)
        self.world = VGroup()                 # 3D content, rebuilt every frame
        self.hud = VGroup()                   # 2D overlay, rebuilt every frame
        self.add(self.world, self.hud)
        for mob in (self.world, self.hud):
            mob.add_updater(lambda m, dt: None)
        self.eq_state = {"tex": None, "t0": 0.0}

        ticker = Mobject()                    # drives everything from the clock

        def tick(_m):
            v = self.clock.get_value()
            if os.environ.get("DEBUG_CLOCK"):
                print("CLOCK", round(v, 3), "phi", round(self.cam.get_phi() / DEGREES, 1),
                      "theta", round(self.cam.get_theta() / DEGREES, 1), flush=True)
            import time as _time
            _t0 = _time.time()
            self.update_frame(v)
            if os.environ.get("PROFILE"):
                print("FRAME", round(v, 2), "update_s", round(_time.time() - _t0, 3),
                      "scene_mobs", len(self.mobjects),
                      "world", len(self.world.family_members_with_points()),
                      "hud", len(self.hud.family_members_with_points()), flush=True)
        ticker.add_updater(tick)
        self.add(ticker)
        self.update_frame(T0)
        self.play(self.clock.animate.set_value(T1), run_time=T1 - T0, rate_func=linear)

    # ------------------------------------------------------------ static parts
    def build_static(self):
        g = VGroup()
        zf = -1.3
        for yy in range(0, K + 1):
            g.add(Line(P(0, yy, zf), P(XL, yy, zf), stroke_color=GRIDc, stroke_width=1.6))
        for xx in np.linspace(0, XL, 9):
            g.add(Line(P(xx, -0.6, zf), P(xx, K + 0.6, zf), stroke_color=GRIDc, stroke_width=1.6))
        g.add(Line(P(0, 0, 0), P(XL + 0.2, 0, 0), stroke_color=AXc, stroke_width=2.2))
        g.add(Line(P(0, 0, 0), P(0, K + 0.6, 0), stroke_color=AXc, stroke_width=2.2))
        g.add(Line(P(0, 0, -1.2), P(0, 0, 1.2), stroke_color=AXc, stroke_width=2.2))
        return g

    # ------------------------------------------------------------ camera
    def set_view(self, t):
        elev, azim = E.camera(t)
        p = elev / E.PERSP[0]
        zoom = 1.02 + (0.78 - 1.02) * p
        if azim <= -58:
            theta = -90 + (azim + 90) * (48 / 32)
        else:
            theta = -42 + (azim + 58) * (42 / 58)
        phi = (90 - elev * 1.15) * DEGREES
        theta *= DEGREES
        self.R = np.dot(rotation_matrix(-phi, RIGHT), rotation_about_z(-theta - 90 * DEGREES))
        sidef = float(np.clip(1 - abs(azim) / 58.0, 0, 1)) if azim > -58 else 0.0
        self.zoom = zoom
        self.off = np.array([1.45 + 1.0 * sidef, -0.25 + 0.55 * p + 0.5 * sidef, 0.0])
        return sidef

    def proj(self, pts):
        """world points (N,3) -> screen points (N,3): rotate, perspective, zoom, offset."""
        pts = np.atleast_2d(pts)
        q = pts @ self.R.T
        f = 20.0
        factor = f / (f - q[:, 2])
        out = np.zeros_like(q)
        out[:, 0] = q[:, 0] * factor * self.zoom
        out[:, 1] = q[:, 1] * factor * self.zoom
        return out + self.off

    def screen(self, p3):
        return self.proj(np.array([p3]))[0]

    def line(self, a, b, **kw):
        return Line(self.screen(a), self.screen(b), **kw)

    # ------------------------------------------------------------ per frame
    def update_frame(self, t):
        side = self.set_view(t)
        world = VGroup()
        hud = VGroup()
        zf = -1.3
        for yy in range(0, K + 1):
            world.add(self.line(P(0, yy, zf), P(XL, yy, zf), stroke_color=GRIDc, stroke_width=1.6))
        for xx in np.linspace(0, XL, 9):
            world.add(self.line(P(xx, -0.6, zf), P(xx, K + 0.6, zf), stroke_color=GRIDc, stroke_width=1.6))
        world.add(self.line(P(0, 0, 0), P(XL + 0.2, 0, 0), stroke_color=AXc, stroke_width=2.2))
        world.add(self.line(P(0, 0, 0), P(0, K + 0.6, 0), stroke_color=AXc, stroke_width=2.2))
        world.add(self.line(P(0, 0, -1.2), P(0, 0, 1.2), stroke_color=AXc, stroke_width=2.2))
        anch = VGroup()           # labels/rings pinned to 3D points (already in screen coords)
        tt = TAU + 0.15 * E.phase(t) if hasattr(E, 'phase') else TAU + 0.15 * t
        prev, cur, m = E.active(t)
        keys = [cur] if prev == cur else [prev, cur]
        Ep, Ec = E.EXOF(prev), E.EXOF(cur)
        front = Ec.full(tt) if prev == cur else (1 - m) * Ep.full(tt) + m * Ec.full(tt)
        drawn = {k: (0.0, None) for k in E.ks}
        for key in keys:
            if key not in E.PEEL:
                continue
            C = E.EXOF(key).comps(tt)
            for k in E.ks:
                mv = E.moved(key, k, t)
                if mv <= 0:
                    continue
                if key == cur or m < 0.02:
                    front = front - mv * C[k - 1]
                if mv > drawn[k][0]:
                    drawn[k] = (mv, C[k - 1])

        # components in their lanes + spectrum bars + rings
        BAR_X = XL + 0.05
        for k in E.ks:
            col = BLUEc if k == 1 else ORANGEc
            mv, c = drawn[k]
            a = min(1.0, mv * 3) * (1 - 0.85 * side)
            if c is not None and a > 0.01:
                world.add(glow_curve(self.proj(PTS(XS, k * mv, c)), col, 2.6, a))
            amp = 0.0
            for key in keys:
                if key in E.PEEL:
                    amp = max(amp, E.EXOF(key).amp[k - 1] * E.moved(key, k, t))
            if amp > 0.005:
                world.add(self.line(P(BAR_X, k, 0), P(BAR_X, k, amp), stroke_color=col,
                               stroke_width=13))
            fk = E.flash(k, t)
            if fk > 0.02:
                c2 = self.screen(P(BAR_X, k, max(amp, 0)))
                anch.add(Circle(radius=0.08 + 0.32 * (1 - fk), stroke_color=col,
                                stroke_width=3, stroke_opacity=fk).move_to(c2))

        # the front signal
        is_sine = E.SC[cur]["ex"] == "sine" and (E.SC[prev]["ex"] == "sine" or m > 0.5)
        fcol = BLUEc if is_sine else INKc
        fa = (1 - 0.85 * side) * (1 - 0.55 * self.sym_dim(t))
        pts = self.proj(PTS(XS, 0, front))
        draw_in = ramp(t, 0.2, 1.8)                   # Manim-style "Create" at the start
        if draw_in < 1:
            n = max(2, int(len(pts) * draw_in))
            pts = pts[:n]
        world.add(glow_curve(pts, fcol, 3.4, fa))

        if "sym" in E.SC:
            self.sym_layer(t, tt, world, anch)

        # setup: ghost sines in every lane (whole multiples that fit)
        s = E.SC["why"]
        ga = ramp(t, s["c"]["lanes"] + 1.2, 0.8) * (1 - ramp(t, s["L"][2][1] + 0.3, 0.8))
        if ga > 0.01:
            for k in E.ks:
                a = ga * ramp(t, s["c"]["lanes"] + 1.2 + 0.12 * k, 0.4)
                if a > 0.01:
                    world.add(curve(self.proj(PTS(XS, k, 0.4 * np.sin(2 * np.pi * k * tt))),
                                    BLUEc if k == 1 else ORANGEc, 2.0, 0.45 * a))

        # lane floor highlights (flash + empty lanes in the square example)
        sq = E.SC["square"]
        empty = ramp(t, sq["c"]["empty"], 0.4) * (1 - ramp(t, sq["c"]["side"] - 0.6, 0.6))
        pulse = 0.5 + 0.5 * np.sin(2 * np.pi * 1.2 * (t - sq["c"]["empty"]))
        lab_a = ramp(t, E._first_peel - 0.6, 0.8) * (1 - ramp(t, E.SC[E.BUILD_KEY]["c"]["close"], 1.5))
        _el, _az = E.camera(t)
        facing = float(np.clip(1 - _el / 6.0, 0, 1) * np.clip(1 - (_az + 90) / 10.0, 0, 1))
        if t > E._first_peel:
            lab_a *= 1 - facing
        for k in E.ks:
            fk = E.flash(k, t)
            is_empty = (k % 2 == 0) and empty > 0
            if is_empty:
                world.add(self.line(P(0, k, -1.3), P(XL, k, -1.3), stroke_color=ORANGEc,
                               stroke_width=4, stroke_opacity=empty * (0.35 + 0.5 * pulse)))
            elif fk > 0.05:
                world.add(self.line(P(0, k, -1.3), P(XL, k, -1.3),
                               stroke_color=BLUEc if k == 1 else ORANGEc,
                               stroke_width=1.6 + 4 * fk, stroke_opacity=0.25 + 0.65 * fk))
            # lane labels: drawn flat on screen so they always face the camera
            la = min(1.0, 0.9 * lab_a + fk)
            if la > 0.02:
                colr = (BLUEc if k == 1 else ORANGEc) if fk > 0.15 else (ORANGEc if is_empty else MUTEDc)
                bold = BOLD if (is_empty or fk > 0.15) else NORMAL
                lab = T(f"{k}X", 18, colr, bold).scale(1 + 0.5 * fk).set_opacity(la)
                anch.add(lab.move_to(self.screen(P(XL + 0.4, k, -0.35))))
        # axis labels
        for txt, p3, a in (("time", P(XL + 0.45, 0, -0.15), 1 - side),
                           ("harmonic", P(0, K + 1.0, -0.15),
                            lab_a * (1 - float(np.clip((E.camera(t)[0] - 26) / 6, 0, 1)))),
                           ("amplitude", P(0, 0, 1.4), 1.0)):
            if a > 0.02:
                anch.add(T(txt, 18, MUTEDc).set_opacity(a).move_to(self.screen(p3)))

        # DC offset line (cut example)
        c = E.SC["cut"]
        da = ramp(t, c["c"]["dc"], 0.5) * (1 - ramp(t, E.SC[E.next_scene("cut")]["start"] - 1.2, 0.6))
        if da > 0.01:
            world.add(DashedLine(self.screen(P(0, 0, E.EX["cut"].dc)), self.screen(P(XL, 0, E.EX["cut"].dc)),
                                 dash_length=0.12, stroke_color=MUTEDc, stroke_width=3,
                                 stroke_opacity=0.9 * da))

        self.world.submobjects = [world]          # replace (become() pads and accumulates)
        self.build_hud(t, hud, prev, cur, anch)

    # ------------------------------------------------------------ symmetry interlude
    def sym_dim(self, t):
        if "sym" not in E.SC:
            return 0.0
        c = E.SC["sym"]["c"]
        area = ramp(t, c["area"] + 1.0, 0.6) * (1 - ramp(t, c["back"], 0.6))
        test = ramp(t, c["test"] + 0.8, 0.6) * (1 - ramp(t, c["area"], 0.6))
        return max(area, 0.75 * test)

    def sym_layer(self, t, tt, world, anch):
        S = E.SC["sym"]
        c = S["c"]
        if not (S["start"] - 0.5 <= t <= S["end"] + 0.5):
            return
        F = E.EX["square"].full
        f = F(tt)
        okc, badc, orc = ManimColor(OKc), ManimColor(BADc), ManimColor(ORANGEc)

        # 1. the whole wave: shift by half a turn, flip about the time axis
        a_cp = ramp(t, c["shift"] - 0.1, 0.4) * (1 - ramp(t, c["test"] - 0.2, 0.6))
        if a_cp > 0.01:
            sh = ramp(t, c["shift"] + 0.3, 1.5)
            ph = np.pi * ramp(t, c["flip"] + 0.4, 1.6)
            z = F(tt + 0.5 * sh)
            g = ramp(t, c["match"], 0.4)
            col = interpolate_color(orc, okc, g)
            world.add(glow_curve(self.proj(PTS(XS, -z * np.sin(ph), z * np.cos(ph))), col, 3.0 + 2.5 * g, a_cp))

        # 2. the same test on lanes 1X, 2X, 3X
        a_t = ramp(t, c["test"] + 1.0, 0.6) * (1 - ramp(t, c["area"], 0.6))
        if a_t > 0.01:
            sh = ramp(t, c["tflip"] + 0.2, 1.3)
            ph = np.pi * ramp(t, c["tflip"] + 1.7, 1.3)
            ver = ramp(t, c["verdict"], 0.4)
            cc = ramp(t, c["cancel"] + 0.4, 1.6)
            for k in (1, 2, 3):
                A = 0.42 * (1 - cc if k == 2 else 1.0)
                base = A * np.sin(2 * np.pi * k * tt)
                world.add(glow_curve(self.proj(PTS(XS, k, base)), BLUEc if k == 1 else ORANGEc, 2.6, a_t))
                if sh > 0:
                    z = A * np.sin(2 * np.pi * k * (tt + 0.5 * sh))
                    col = interpolate_color(ManimColor(INKc), okc if k % 2 else badc, ver)
                    world.add(glow_curve(self.proj(PTS(XS, k - z * np.sin(ph), z * np.cos(ph))), col,
                                         2.4 + 2.0 * ver * (k % 2), a_t * min(1.0, sh * 4)))
                if ver > 0.01:
                    p_ = self.screen(P(XL + 1.15, k, 0.25))
                    if k % 2:
                        mk = VMobject(stroke_color=OKc, stroke_width=7).set_points_as_corners(
                            [p_ + np.array([-0.18, 0, 0]), p_ + np.array([-0.04, -0.15, 0]), p_ + np.array([0.21, 0.2, 0])])
                    else:
                        d = 0.16
                        mk = VGroup(Line(p_ + np.array([-d, -d, 0]), p_ + np.array([d, d, 0]), stroke_color=BADc, stroke_width=7),
                                    Line(p_ + np.array([-d, d, 0]), p_ + np.array([d, -d, 0]), stroke_color=BADc, stroke_width=7))
                    anch.add(mk.set_stroke(opacity=ver * a_t))

        # 3. every even lane is forced to zero
        ev = ramp(t, c["evens"], 0.4) * (1 - ramp(t, c["area"] - 0.3, 0.5))
        if ev > 0.01:
            pulse = 0.5 + 0.5 * np.sin(2 * np.pi * 1.2 * (t - c["evens"]))
            for k in (2, 4, 6, 8, 10):
                world.add(self.line(P(0, k, -1.3), P(XL, k, -1.3), stroke_color=ORANGEc, stroke_width=4,
                                    stroke_opacity=ev * (0.35 + 0.5 * pulse)))

        # 4. each harmonic is an area: f(t) sin(n w0 t), swept left to right
        for n, k0, k1 in ((2, "sweep2", "sweep3"), (3, "sweep3", "back")):
            end = c[k1] - 0.4 if n == 2 else c[k1] + 0.8
            a_n = ramp(t, c[k0] - 0.2, 0.5) * (1 - ramp(t, end, 0.5))
            if a_n < 0.01:
                continue
            sn = np.sin(2 * np.pi * n * tt)
            prod = f * sn
            world.add(curve(self.proj(PTS(XS, 0, 0.8 * sn)), BLUEc, 2.2, 0.55 * a_n))
            world.add(glow_curve(self.proj(PTS(XS, 0, prod)), ORANGEc, 2.6, a_n))
            u = float(np.clip((t - c[k0] - 0.6) / 4.0, 0, 1))
            val = 0.0
            if u > 0:
                i1 = max(2, int(len(XS) * u))
                for sgn, col in ((1, OKc), (-1, BADc)):
                    part = np.where(sgn * prod[:i1] > 0, prod[:i1], 0.0)
                    pts3 = np.vstack([P(XS[0], 0, 0), PTS(XS[:i1], 0, part), P(XS[i1 - 1], 0, 0)])
                    world.add(Polygon(*self.proj(pts3), stroke_width=0, fill_color=col, fill_opacity=0.42 * a_n))
                xs_ = XS[i1 - 1]
                if u < 1:
                    world.add(DashedLine(self.screen(P(xs_, 0, -1.25)), self.screen(P(xs_, 0, 1.25)),
                                         dash_length=0.08, stroke_color=INKc, stroke_width=2, stroke_opacity=a_n))
                # over two periods: (2/T) * integral over one period = integral over both (T = 1)
                val = float(np.sum((prod[1:i1] + prod[:i1 - 1]) / 2 * np.diff(tt[:i1])))
            lbl = TEX(rf"b_{n}=", 42)
            num = DecimalNumber(abs(val) if abs(val) < 0.005 else val, num_decimal_places=2,
                                font_size=42, color=INKc)
            ro = VGroup(lbl, num).arrange(RIGHT, buff=0.15).set_opacity(a_n)
            anch.add(ro.move_to(FIG(0.97, 0.80), aligned_edge=RIGHT))

    # ------------------------------------------------------------ 2D overlay
    def build_hud(self, t, hud, prev, cur, anch):
        first_end = E.SC["intro"]["L"][0][1]
        ha = 1 - ramp(t, first_end - 0.4, 0.5)
        if ha > 0.01:
            hud.add(T("Why do we see harmonics?", 54, INKc, BOLD).set_opacity(ha)
                    .move_to(FIG(0.5, 0.905)))
        key = cur if t >= E.SC[cur]["start"] - 0.2 else prev
        if t >= E.SC[E.BUILD_KEY]["start"] - 0.2:
            key = E.BUILD_KEY
        S = E.SC[key]
        ta = ramp(t, max(S["start"], first_end if key == "intro" else 0) - 0.2, 0.5)
        if ta > 0.01:
            kk = T(S["kicker"], 17, ORANGEc, BOLD).set_opacity(ta)
            kk.move_to(FIG(0.03, 0.966), aligned_edge=LEFT)
            tl = T(S["title"], 36, INKc, BOLD).set_opacity(ta)
            tl.move_to(FIG(0.03, 0.905), aligned_edge=LEFT)
            hud.add(kk, tl)
        for rk, t0, txt in E.RESULTS:
            if t0 <= t < E.SC[E.next_scene(rk)]["start"] - 0.3:
                r = T(txt, 26, ORANGEc, BOLD).set_opacity(ramp(t, t0, 0.5))
                hud.add(r.move_to(FIG(0.97, 0.912), aligned_edge=RIGHT))

        # maths row: each new formula WRITES itself on (Manim's Write animation)
        cur_eq = None
        for t0, tex in E.EQS:
            if t >= t0:
                cur_eq = (t0, tex)
        if cur_eq and t <= E.EQ_END + 0.4:
            t0, tex = cur_eq
            mob = TEX(tex, 40)
            mob.move_to(FIG(0.03, 0.805), aligned_edge=LEFT)
            alpha = (t - t0) / 1.1
            if alpha < 1:
                anim = Write(mob)
                anim.begin()
                anim.interpolate(max(alpha, 0.0))
            fade = 1 - ramp(t, E.EQ_END, 0.4)
            if fade < 1:
                mob.set_opacity(fade)
            hud.add(mob)

        # caption: glides in from slightly below
        for l in E.ALL_LINES:
            if l["start"] - 0.05 <= t <= l["end"]:
                import textwrap
                lines = textwrap.wrap(l["text"], 52)
                txt = VGroup(*[T(x, 28, INKc, BOLD) for x in lines]).arrange(DOWN, buff=0.12)
                a = ramp(t, l["start"], 0.25)
                box = RoundedRectangle(corner_radius=0.12, width=txt.width + 0.6,
                                       height=txt.height + 0.4, fill_color="#000000",
                                       fill_opacity=0.62 * a, stroke_width=0)
                cap = VGroup(box, txt.set_opacity(a))
                cap.move_to(FIG(0.56, 0.075) + DOWN * 0.15 * (1 - a))
                if cap.get_right()[0] > FW / 2 - 0.3:
                    cap.shift(LEFT * (cap.get_right()[0] - (FW / 2 - 0.3)))
                hud.add(cap)
                break

        self.mascot(t, hud)
        veil = max(1 - ramp(t, 0, 0.6), ramp(t, E.DURATION - 0.8, 0.7))
        if veil > 0.01:
            hud.add(Rectangle(width=FW + 1, height=FH + 1, fill_color=SURF,
                              fill_opacity=veil, stroke_width=0))
        if os.environ.get("PROFILE2"):
            print("HUDPARTS", round(t, 2), [(type(m).__name__, len(m.family_members_with_points())) for m in hud.submobjects],
                  "anch", len(anch.family_members_with_points()), flush=True)
        self.hud.submobjects = [VGroup(anch, hud)]
        # Manim fixes the list of objects to draw when play() starts; refresh it
        # every frame so the newly built layers (not the first frame's) are drawn
        self.moving_mobjects = extract_mobject_family_members([self.world, self.hud])

    # ------------------------------------------------------------ mascot
    def mascot(self, t, hud):
        M = E.MASC
        if M is None:
            return
        appear = M.start_of("appear", t)
        # mascot box: same place as the Matplotlib layout (left column)
        ox, oy, sc = FIG(0.105, 0.31), None, 1.55
        base = FIG(0.105, 0.31)

        def Q(x, y):            # mascot-local coords (x 0..1, y -1..1) -> frame
            return base + np.array([(x - 0.5) * sc, y * sc, 0])

        g = VGroup()
        if appear is not None:
            pop = float(np.clip(1 + 2.9 * ((t - appear) / 0.5 - 1) ** 3 + 1.9 * ((t - appear) / 0.5 - 1) ** 2, 0, 1.2)) \
                if t - appear < 0.5 else 1.0
            happy, surprise = M.level("happy", t), M.level("surprise", t)
            excited, dizzy, wink = M.level("excited", t), M.level("dizzy", t), M.level("wink", t)
            x = M.x
            A = 0.42
            y = A * M.body_shape(t)
            bob = 0.03 * np.sin(2 * np.pi * 0.55 * t)
            hop = 0.0
            if happy > 0:
                hop = 0.16 * happy * abs(np.sin(2 * np.pi * 1.6 * (t - M.start_of("happy", t))))
            wob = 0.0
            if dizzy > 0:
                y = y + 0.05 * dizzy * np.sin(2 * np.pi * 3 * x + 9 * t)
                wob = 0.04 * dizzy * np.sin(7 * t)
            squash = 1.0
            ts = M.start_of("slam", t)
            if ts is not None and t - ts < 0.6:
                squash = 1 - 0.25 * np.exp(-(t - ts) / 0.12) * np.cos(25 * (t - ts))
            yy = (y * squash + bob + hop) * pop
            xx = 0.5 + (x - 0.5) * pop + wob
            # clamp under it in the cut example
            cl = 0.0
            if M.clamp_on - 0.05 <= t:
                u = np.clip((t - M.clamp_on) / 0.25, 0, 1)
                up = 1 + 2.9 * (u - 1) ** 3 + 1.9 * (u - 1) ** 2
                cl = up * (1 - ramp(t, M.clamp_off, 0.4))
            if cl > 0.01:
                top = -0.95 + (0.95 - A - 0.07 + bob + hop) * cl
                r = Polygon(Q(-0.12, -0.95), Q(1.12, -0.95), Q(1.12, top), Q(-0.12, top),
                            fill_color="#3a3936", fill_opacity=1, stroke_color=MUTEDc, stroke_width=2)
                g.add(r)
            body = np.array([Q(a, b) for a, b in zip(xx, yy)])
            g.add(curve(body, BLUEc, 34, 0.12), curve(body, BLUEc, 14, 1.0))
            # face
            xe = np.array([0.15, 0.35])
            ye_body = np.interp(xe, x, yy / max(pop, 1e-3)) * pop
            rr = 0.095 * pop * (1 + 0.22 * excited + 0.35 * surprise)
            eye_y = ye_body + 0.17 * pop
            exe = 0.5 + (xe - 0.5) * pop + wob
            blink = 0.12 if ((t + 0.7) % 3.6) < 0.13 else 1.0
            gx, gy = (0.95, 0.1) if surprise > 0 else (0.75, 0.45)
            if dizzy > 0.3:
                gx, gy = np.cos(6 * t), np.sin(6 * t)
            gn = np.hypot(gx, gy)
            px, py = gx / gn, gy / gn
            for i, (ex_, ey_) in enumerate(zip(exe, eye_y)):
                if happy > 0.5:
                    g.add(curve(np.array([Q(ex_ - 0.9 * rr, ey_ - 0.3 * rr), Q(ex_, ey_ + 0.45 * rr),
                                          Q(ex_ + 0.9 * rr, ey_ - 0.3 * rr)]), INKc, 6))
                    continue
                b = 0.1 if (i == 0 and wink > 0.4) else blink
                if b > 0.3:
                    eye = Ellipse(width=2 * rr * sc, height=2 * rr * b * sc, fill_color=INKc,
                                  fill_opacity=1, stroke_width=0).move_to(Q(ex_, ey_))
                    pr = rr * (0.42 if surprise < 0.5 else 0.3)
                    pupil = Circle(radius=pr * sc, fill_color=SURF, fill_opacity=1, stroke_width=0
                                   ).move_to(Q(ex_ + 0.45 * rr * px, ey_ + 0.45 * rr * py * b))
                    shine = Dot(Q(ex_ + 0.45 * rr * px + pr * 0.35, ey_ + 0.45 * rr * py + pr * 0.4),
                                radius=0.02, color=INKc)
                    g.add(eye, pupil, shine)
                else:
                    g.add(Line(Q(ex_ - 0.9 * rr, ey_), Q(ex_ + 0.9 * rr, ey_), stroke_color=INKc,
                               stroke_width=5))
            mx = 0.5 + (0.25 - 0.5) * pop + wob
            my = np.interp(0.25, x, yy / max(pop, 1e-3)) * pop - 0.2 * pop
            if surprise > 0.4:
                g.add(Ellipse(width=0.09 * sc, height=0.12 * sc, fill_color=INKc, fill_opacity=1,
                              stroke_width=0).move_to(Q(mx, my)))
            else:
                cv = 0.05 + 0.07 * happy - 0.06 * dizzy
                s_ = np.linspace(-1, 1, 16)
                g.add(curve(np.array([Q(mx + 0.09 * a * pop, my + cv * a ** 2 * pop) for a in s_]),
                            INKc, 5))
            if dizzy > 0.05:
                for i in range(3):
                    ang = 4 * t + i * 2 * np.pi / 3
                    g.add(Star(n=5, outer_radius=0.07, fill_color="#eda100", fill_opacity=dizzy,
                               stroke_width=0).move_to(Q(0.25 + 0.26 * np.cos(ang),
                                                          eye_y.max() + 0.25 + 0.07 * np.sin(ang))))
            # confetti
            tc = M.start_of("confetti", t)
            if tc is not None and t - tc < 1.9:
                u = t - tc
                cf = M.conf
                for i in range(len(cf["vx"])):
                    fx_ = 0.1 + cf["vx"][i] * 0.55 * u
                    fy_ = 0.36 + cf["vy"][i] * u - 0.55 * u ** 2
                    g.add(Square(side_length=0.06 + 0.03 * (cf["s"][i] / 11), fill_color=cf["c"][i],
                                 fill_opacity=max(0.0, 1 - u / 1.9), stroke_width=0)
                          .rotate(cf["spin"][i] + 9 * u).move_to(FIG(fx_, fy_)))
        # speech bubble
        for t0, d, s in M.bubbles:
            if t0 <= t <= t0 + d:
                import textwrap
                a = min(ramp(t, t0, 0.15), 1 - ramp(t, t0 + d - 0.15, 0.15))
                lines = textwrap.wrap(s, 15)
                tx = VGroup(*[T(x, 20, INKc, BOLD) for x in lines]).arrange(DOWN, buff=0.08)
                box = RoundedRectangle(corner_radius=0.12, width=tx.width + 0.4, height=tx.height + 0.3,
                                       fill_color="#1d1d1b", fill_opacity=0.95 * a,
                                       stroke_color=BLUEc, stroke_width=3, stroke_opacity=a)
                bub = VGroup(box, tx.set_opacity(a)).move_to(FIG(0.115, 0.56) + UP * 0.12 * (1 - ramp(t, t0, 0.2)))
                g.add(bub)
                break
        hud.add(g)
