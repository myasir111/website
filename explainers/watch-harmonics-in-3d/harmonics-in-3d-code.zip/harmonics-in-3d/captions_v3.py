"""Story v2 (sound-only, captions):
   1 a pure sine -> one peak      2 a messy real signal -> many peaks   3 why?
   4-7 examples (square, sawtooth, triangle, cut)   8 back to the messy signal,
   now every peak makes sense      9 rebuild + close

Writes timeline_v2.json. Each scene names the signal ("ex") it shows.
Cue tags: [intro] [peel] [side] [morph] [lanes] [empty] [dc] [build] [close]
"""
import json, re

SCENES = [  # (key, ex, title, kicker, lines)
    ("intro", "sine", "One pure sine", "PART 1", [
        "Every spectrum has peaks at 1X, 2X, 3X… but where do they come from?",
        "[intro] Start with the simplest signal there is: a pure sine.",
        "[peel] Split it into its frequencies… {+1.0}",
        "[side] …one sine, one peak, at 1X. {+1.6}",
    ]),
    ("messy", "real", "A real machine signal", "PART 2", [
        "[morph] Now a real machine signal: imbalance, misalignment, an impact every turn. {+0.4}",
        "[peel] Split it the same way… {+3.0}",
        "[side] …and there are peaks everywhere: 1X, 2X, 3X, 4X… {+1.4}",
        "So why does one repeating signal give so many peaks? {+0.4}",
    ]),
    ("why", "sine", "Only whole multiples fit", "THE REASON", [
        "[morph] The signal repeats every revolution.",
        "[lanes] Only sines and cosines at whole multiples of running speed fit that repeat. {+1.0}",
        "So any repeating signal splits into these lanes. Its shape decides which ones fill.",
        "Let's see that with some simple shapes. {+0.2}",
    ]),
    ("square", "square", "Square wave", "EXAMPLE 1", [
        "[morph] A square wave.",
        "[peel] Pull out its sine waves: 1X, 3X, 5X, 7X, 9X… {+2.4}",
        "[empty] The even lanes stay empty. {+0.6}",
        "Not small. Exactly zero. Why? Hold that thought. {+0.2}",
        "[side] From the side, that's the spectrum: odd only, falling as 1/n. {+2.0}",
    ]),
    ("sym", "square", "Half-wave symmetry", "WHY EXACTLY ZERO?", [
        "[flat] Here's why. Look at the square wave straight on. {+0.6}",
        "[shift] Shift it by half a turn… {+1.0}",
        "[flip] …and flip it upside down. {+1.2}",
        "[match] It lands exactly on itself. {+0.8}",
        "Every half turn, it pushes down exactly as hard as it pushed up. {+0.3}",
        "[test] Now give each harmonic lane the same test. {+0.8}",
        "[tflip] Shift each one by half a turn, and flip it. {+1.4}",
        "[verdict] 1X and 3X land on themselves. 2X comes back upside down. {+0.8}",
        "Half a turn is a full 2X cycle, so the flip leaves it inverted. {+0.3}",
        "[cancel] But the wave must match itself, so its 2X part equals its own negative: zero. {+1.4}",
        "[evens] Same for 4X, 6X, 8X: every even lane is forced to zero. {+0.6}",
        "[area] Another way to see it: each harmonic is an area. {+0.6}",
        "[sweep2] Multiply by 2X and add it up as we sweep. Green adds, red takes away. {+1.6}",
        "[zero2] For 2X, they cancel perfectly. {+0.6}",
        "[sweep3] For 3X, they don't cancel. They add up to 4/(3π). {+2.0}",
        "[back] So symmetry decides which lanes stay empty. Now a shape without it… {+0.4}",
    ]),
    ("sawtooth", "sawtooth", "Sawtooth", "EXAMPLE 2", [
        "[morph] A sawtooth.",
        "[peel] No flip symmetry, so every lane fills. {+2.6}",
    ]),
    ("triangle", "triangle", "Triangle wave", "EXAMPLE 3", [
        "[morph] A triangle: symmetric again, so odd lanes only.",
        "[peel] Corners instead of jumps, so harmonics shrink as 1/n². {+2.0}",
    ]),
    ("cut", "cut", "Sine cut on one side", "EXAMPLE 4", [
        "[morph] A sine cut off on one side, like a loose part. {+0.6}",
        "[peel] Symmetry broken: even harmonics appear. {+2.0}",
        "[dc] What's left is a constant offset: the DC term. {+0.8}",
    ]),
    ("payoff", "real", "Now the peaks make sense", "BACK TO THE MESSY SIGNAL", [
        "[morph] Back to our messy signal. {+0.3}",
        "[peel] Imbalance → 1X. Misalignment → 2X. The ringing impact → 4X to 7X. {+2.6}",
        "[side] Every peak in your spectrum is one of these lanes. {+1.6}",
    ]),
    ("build", "real", "Put it back together", "RECONSTRUCT", [
        "[build] Push every sine and cosine back in… {+3.4}",
        "…and the original signal returns.",
        "[close] Harmonics aren't extra signals. They're the shape, written as sines and cosines. {+1.8}",
    ]),
]

LEAD_IN = 0.8
SCENE_GAP = 1.7


def read_time(text):
    words = len(text.split())
    return max(1.9, 0.29 * words + 0.9)


t = LEAD_IN
scenes = []
for key, ex, title, kicker, lines in SCENES:
    sc = {"key": key, "ex": ex, "title": title, "kicker": kicker, "start": t,
          "cues": {}, "lines": []}
    for raw in lines:
        hold = 0.0
        mh = re.search(r"\{\+([\d.]+)\}\s*$", raw)
        if mh:
            hold = float(mh.group(1))
            raw = raw[:mh.start()].rstrip()
        m = re.match(r"\[(\w+)\]\s*(.*)", raw)
        tag, text = (m.group(1), m.group(2)) if m else (None, raw)
        if tag:
            sc["cues"][tag] = t
        d = read_time(text) + hold
        sc["lines"].append({"text": text, "start": t, "end": t + d - 0.12})
        t += d
    t += SCENE_GAP
    sc["end"] = t
    scenes.append(sc)

t += 1.0   # tail
json.dump({"voice": None, "duration": t, "scenes": scenes},
          open("timeline_v3.json", "w"), indent=1)
print(f"duration {t:.1f} s")
for s in scenes:
    print(f"{s['key']:9s} {s['start']:6.1f} -> {s['end']:6.1f}",
          {k: round(v - s['start'], 1) for k, v in s['cues'].items()})
